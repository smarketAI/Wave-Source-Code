﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.App
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using Microsoft.CSharp.RuntimeBinder;
using Sentry;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using WaveWindows.Interfaces;

namespace WaveWindows
{
  public partial class App : Application
  {

    protected override async void OnStartup(
    StartupEventArgs e)
    {
      App app = this;
      // ISSUE: reference to a compiler-generated method
      app.Startup(e);
      string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
      SentrySdk.Init((Action<SentryOptions>) (options =>
      {
        options.Dsn = "https://a352f01cb1f58eb397503466ac938008@o953144.ingest.us.sentry.io/4507556325425152";
        options.Debug = true;
        options.TracesSampleRate = new double?(1.0);
        options.ProfilesSampleRate = new double?(1.0);
        options.AttachStacktrace = true;
        options.SendDefaultPii = true;
      }));
      // ISSUE: reference to a compiler-generated method
      AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(app.\u003COnStartup\u003Eb__0_1);
      // ISSUE: reference to a compiler-generated method
      app.DispatcherUnhandledException += new DispatcherUnhandledExceptionEventHandler(app.\u003COnStartup\u003Eb__0_2);
      // ISSUE: reference to a compiler-generated method
      TaskScheduler.UnobservedTaskException += new EventHandler<UnobservedTaskExceptionEventArgs>(app.\u003COnStartup\u003Eb__0_3);
      try
      {
        if (Process.GetProcessesByName("WaveWindows").Length > 1)
          throw new Exception("Another instance of Wave is already running.");
        if (Assembly.GetEntryAssembly().Location.StartsWith(Path.GetTempPath(), StringComparison.OrdinalIgnoreCase))
          throw new Exception("Please extract the Wave archive to a folder.");
      }
      catch (Exception ex)
      {
        app.InterceptException(ex);
      }
      try
      {
        Process process = await LanguageServerInterface.TryLaunch();
        // ISSUE: reference to a compiler-generated method
        process.Exited += new EventHandler(app.\u003COnStartup\u003Eb__0_4);
        process.Start();
      }
      catch
      {
        app.InterceptException(new Exception("The Language Server Protocol has failed to start."));
      }
    }

    private void InterceptException(Exception ex)
    {
      if (ex == null)
        return;
      SentrySdk.CaptureException(ex);
      this.InvokeError(ex.Message, this.GetUnhandledExceptionErrorType(ex));
    }

    private UnhandledExceptionErrorType GetUnhandledExceptionErrorType(Exception ex)
    {
      return ex.InnerException is FileNotFoundException ? UnhandledExceptionErrorType.RegistryError : UnhandledExceptionErrorType.ApplicationError;
    }

    private void InvokeError(
      string message,
      UnhandledExceptionErrorType unhandledExceptionErrorType)
    {
      Application.Current.Dispatcher.Invoke((Action) (() =>
      {
        object mainWindow = (object) (Application.Current.MainWindow as LoginWindow);
        // ISSUE: reference to a compiler-generated field
        if (App.\u003C\u003Eo__3.\u003C\u003Ep__1 == null)
        {
          // ISSUE: reference to a compiler-generated field
          App.\u003C\u003Eo__3.\u003C\u003Ep__1 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (App), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, bool> target1 = App.\u003C\u003Eo__3.\u003C\u003Ep__1.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, bool>> p1 = App.\u003C\u003Eo__3.\u003C\u003Ep__1;
        // ISSUE: reference to a compiler-generated field
        if (App.\u003C\u003Eo__3.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          App.\u003C\u003Eo__3.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (App), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj1 = App.\u003C\u003Eo__3.\u003C\u003Ep__0.Target((CallSite) App.\u003C\u003Eo__3.\u003C\u003Ep__0, mainWindow, (object) null);
        if (target1((CallSite) p1, obj1))
          mainWindow = (object) (Application.Current.MainWindow as WaveWindows.MainWindow);
        // ISSUE: reference to a compiler-generated field
        if (App.\u003C\u003Eo__3.\u003C\u003Ep__3 == null)
        {
          // ISSUE: reference to a compiler-generated field
          App.\u003C\u003Eo__3.\u003C\u003Ep__3 = CallSite<Func<CallSite, object, bool>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof (App), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[1]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        Func<CallSite, object, bool> target2 = App.\u003C\u003Eo__3.\u003C\u003Ep__3.Target;
        // ISSUE: reference to a compiler-generated field
        CallSite<Func<CallSite, object, bool>> p3 = App.\u003C\u003Eo__3.\u003C\u003Ep__3;
        // ISSUE: reference to a compiler-generated field
        if (App.\u003C\u003Eo__3.\u003C\u003Ep__2 == null)
        {
          // ISSUE: reference to a compiler-generated field
          App.\u003C\u003Eo__3.\u003C\u003Ep__2 = CallSite<Func<CallSite, object, object, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof (App), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        object obj2 = App.\u003C\u003Eo__3.\u003C\u003Ep__2.Target((CallSite) App.\u003C\u003Eo__3.\u003C\u003Ep__2, mainWindow, (object) null);
        if (target2((CallSite) p3, obj2))
          Environment.FailFast(message, new Exception(message));
        // ISSUE: reference to a compiler-generated field
        if (App.\u003C\u003Eo__3.\u003C\u003Ep__4 == null)
        {
          // ISSUE: reference to a compiler-generated field
          App.\u003C\u003Eo__3.\u003C\u003Ep__4 = CallSite<Action<CallSite, object, UnhandledExceptionErrorType, string>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.InvokeMember(CSharpBinderFlags.ResultDiscarded, "ShowUnhandledExceptionError", (IEnumerable<Type>) null, typeof (App), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[3]
          {
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null),
            CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType, (string) null)
          }));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        App.\u003C\u003Eo__3.\u003C\u003Ep__4.Target((CallSite) App.\u003C\u003Eo__3.\u003C\u003Ep__4, mainWindow, unhandledExceptionErrorType, message);
      }));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      this.StartupUri = new Uri("LoginWindow.xaml", UriKind.Relative);
      Application.LoadComponent((object) this, new Uri("/WaveWindows;component/app.xaml", UriKind.Relative));
    }

    [STAThread]
    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public static void Main()
    {
      App app = new App();
      app.InitializeComponent();
      app.Run();
    }
  }
}
