﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.MainWindow
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using Microsoft.Win32;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using WaveWindows.Controls;
using WaveWindows.Controls.Card;
using WaveWindows.Controls.Editor;
using WaveWindows.Controls.Settings;
using WaveWindows.Interfaces;
using WaveWindows.Modules;

#nullable enable
namespace WaveWindows
{
  public partial class MainWindow : Window, IComponentConnector
  {
    internal static readonly 
    #nullable disable
    DependencyProperty CurrentPageSelectionProperty = DependencyProperty.Register(nameof (CurrentPageSelection), typeof (PageState), typeof (MainWindow));
    internal OverlayState CurrentOverlaySelection;
    private readonly WmiProcessWatcher WmiWatcher = new WmiProcessWatcher("RobloxPlayerBeta");
    private readonly SocketServer SocketServer = new SocketServer("ws://localhost:60137");
    private readonly List<string> SelectedClients = new List<string>();
    private readonly RestClient RobloxThumbnailApi = new RestClient("https://thumbnails.roblox.com/v1", (ConfigureRestClient) null, (ConfigureHeaders) null, (ConfigureSerialization) null);
    private readonly EditorInterface.EditorOptions EditorOptions = new EditorInterface.EditorOptions()
    {
      FontSize = 14,
      Minimap = new EditorInterface.MinimapOptions()
      {
        Enabled = true
      },
      InlayHints = new EditorInterface.InlayHintsOptions()
      {
        Enabled = true
      }
    };
    private int References = 1;
    private bool IsSidePanelShown = true;
    private EventHandler OnClientReady;
    private bool IsClientReady;
    internal Border Background;
    internal BlurEffect BlurEffect;
    internal ToggleButton EditorToggleButton;
    internal ToggleButton ScriptCloudToggleButton;
    internal ToggleButton SettingsToggleButton;
    internal ToggleButton ManagerToggleButton;
    internal ToggleButton LicenseToggleButton;
    internal Border PageSelectionBar;
    internal TextBlock IsInjectedText;
    internal WaveWindows.Controls.Button ExitButton;
    internal WaveWindows.Controls.Button MaximizeButton;
    internal WaveWindows.Controls.Button MinimizeButton;
    internal Border EditorPage;
    internal Border SidePanel;
    internal ListView MessageList;
    internal WaveWindows.Controls.InputBox InputBox;
    internal Border EditorPanel;
    internal WaveWindows.Controls.Editor.TabControl EditorTabControl;
    internal WaveWindows.Controls.Button ExecuteButton;
    internal WaveWindows.Controls.Button ClearButton;
    internal WaveWindows.Controls.Button SaveFileButton;
    internal WaveWindows.Controls.Button OpenFileButton;
    internal Border SidePanelButton;
    internal Border ScriptCloudPage;
    internal WaveWindows.Controls.InputBox SearchBox;
    internal WaveWindows.Controls.Button PreviousPageButton;
    internal TextBlock CurrentPageText;
    internal WaveWindows.Controls.Button NextPageButton;
    internal WrapPanel ScriptList;
    internal Grid NoResultSection;
    internal Border SettingsPage;
    internal WaveWindows.Controls.Button SettingsExecutorToggleButton;
    internal WaveWindows.Controls.Button SettingsEditorToggleButton;
    internal WaveWindows.Controls.Button SettingsArtificialIntelligenceToggleButton;
    internal Grid SettingsExecutorSection;
    internal WaveWindows.Controls.Settings.CheckBox ContinueOnStartUpCheckBox;
    internal WaveWindows.Controls.Settings.CheckBox TopMostCheckBox;
    internal WaveWindows.Controls.Settings.CheckBox RedirectCompilerErrorCheckBox;
    internal WaveWindows.Controls.Settings.CheckBox UsePerformanceModeCheckBox;
    internal Grid SettingsEditorSection;
    internal WaveWindows.Controls.Settings.Slider RefreshRateSlider;
    internal WaveWindows.Controls.Settings.Slider FontSizeSlider;
    internal WaveWindows.Controls.Settings.CheckBox MinimapCheckBox;
    internal WaveWindows.Controls.Settings.CheckBox InlayHintsCheckBox;
    internal Grid SettingsArtificialIntelligenceSection;
    internal WaveWindows.Controls.Settings.CheckBox SendCurrentDocumentCheckBox;
    internal Grid ManagerOverlayContainer;
    internal Border ManagerOverlay;
    internal StackPanel ClientList;
    internal Grid LicenseOverlayContainer;
    internal Border LicenseOverlay;
    internal TextBlock DurationText;
    internal TextBlock MembershipText;
    internal WaveWindows.Controls.InputBox LicenseKeyBox;
    internal WaveWindows.Controls.Button JoinNowButton;
    internal Border LoadingOverlay;
    internal Border LoadingCircle;
    internal RotateTransform SubmitButtonRotateTransform;
    internal WaveWindows.Controls.Toast.Container ToastNotification;
    internal UnhandledExceptionError UnhandledExceptionError;
    internal Border AdContainer;
    internal ImageBrush AdImage;
    private bool _contentLoaded;

    internal PageState CurrentPageSelection
    {
      get => (PageState) this.GetValue(MainWindow.CurrentPageSelectionProperty);
      set => this.SetValue(MainWindow.CurrentPageSelectionProperty, (object) value);
    }

    private Types.WaveAPI.User User { get; set; }

    private Types.WaveAPI.Product Product { get; set; }

    private List<Types.WaveAPI.Message> Messages { get; set; }

    private string Session { get; set; }

    private string SearchQuery { get; set; }

    private SearchResult SearchResult { get; set; }

    public MainWindow(string session)
    {
      this.InitializeComponent();
      this.Session = session;
    }

    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
      MainWindow sender1 = this;
      try
      {
        Types.WaveAPI.User userAsync = await WaveInterface.GetUserAsync(sender1.Session);
        sender1.User = userAsync;
        sender1.Product = sender1.User.Products.FirstOrDefault<Types.WaveAPI.Product>((Func<Types.WaveAPI.Product, bool>) (x => x.Name == "premium-wave")) ?? sender1.User.Products.FirstOrDefault<Types.WaveAPI.Product>((Func<Types.WaveAPI.Product, bool>) (x => x.Name == "freemium-wave")) ?? (Types.WaveAPI.Product) null;
        try
        {
          Types.WaveAPI.HistoryResponse historyResponse = await WaveInterface.FetchHistoryAsync(sender1.Session);
          sender1.Messages = historyResponse.Messages;
        }
        catch
        {
          sender1.Messages = new List<Types.WaveAPI.Message>();
        }
        sender1.ToggleLoading(false);
        sender1.LoadUserData();
        sender1.LoadMessages();
      }
      catch (Exception ex)
      {
        sender1.ToastNotification.Error(ex.Message);
        await Task.Delay(3000);
        WaveWindows.Modules.Registry.Configuration.Session = "";
        sender1.BackToLogin();
      }
      Initializer.Once();
      sender1.EditorTabControl.AddTab("Untitled Tab", "print(\"Hello World!\");");
      AdvertisementInterface Advertisement = AdvertisementInterface.Random();
      sender1.AdContainer.MouseDown += (MouseButtonEventHandler) ((src, args) =>
      {
        if (string.IsNullOrEmpty(Advertisement.Image))
          return;
        Process.Start(Advertisement.Link);
      });
      sender1.AdImage.ImageSource = (ImageSource) new BitmapImage(new Uri("pack://application:,,,/WaveWindows;component/" + Advertisement.Image, UriKind.Absolute));
      sender1.ContinueOnStartUpCheckBox.IsChecked = WaveWindows.Modules.Registry.Configuration.ContinueOnStartUp;
      sender1.TopMostCheckBox.IsChecked = WaveWindows.Modules.Registry.Configuration.TopMost;
      sender1.RedirectCompilerErrorCheckBox.IsChecked = WaveWindows.Modules.Registry.Configuration.RedirectCompilerError;
      sender1.UsePerformanceModeCheckBox.IsChecked = WaveWindows.Modules.Registry.Configuration.UsePerformanceMode;
      sender1.RefreshRateSlider.Value = (double) WaveWindows.Modules.Registry.Configuration.RefreshRate;
      sender1.FontSizeSlider.Value = (double) WaveWindows.Modules.Registry.Configuration.FontSize;
      sender1.MinimapCheckBox.IsChecked = WaveWindows.Modules.Registry.Configuration.Minimap;
      sender1.InlayHintsCheckBox.IsChecked = WaveWindows.Modules.Registry.Configuration.InlayHints;
      sender1.SendCurrentDocumentCheckBox.IsChecked = WaveWindows.Modules.Registry.Configuration.SendCurrentDocument;
      sender1.EditorOptions.FontSize = WaveWindows.Modules.Registry.Configuration.FontSize;
      sender1.EditorOptions.Minimap.Enabled = WaveWindows.Modules.Registry.Configuration.Minimap;
      sender1.EditorOptions.InlayHints.Enabled = WaveWindows.Modules.Registry.Configuration.InlayHints;
      sender1.EditorTabControl.SetEditorOptions(sender1.EditorOptions);
      if (WaveWindows.Modules.Registry.Configuration.ContinueOnStartUp)
      {
        sender1.LoadCurrentWorkspace(Hardware.CurrentProfile.Guid);
        // ISSUE: reference to a compiler-generated method
        sender1.Closing += new CancelEventHandler(sender1.\u003CWindow_Loaded\u003Eb__39_0);
      }
      // ISSUE: reference to a compiler-generated method
      sender1.OnClientReady += new EventHandler(sender1.\u003CWindow_Loaded\u003Eb__39_1);
      try
      {
        // ISSUE: reference to a compiler-generated method
        await InjectorInterface.GetBinariesAsync(new Action<string, double>(sender1.\u003CWindow_Loaded\u003Eb__39_8));
        EventHandler onClientReady = sender1.OnClientReady;
        if (onClientReady != null)
          onClientReady((object) sender1, EventArgs.Empty);
      }
      catch
      {
        WaveWindows.Controls.Toast.Container container = sender1.ToastNotification;
        container.Error("Wave is currently outdated. (" + await InjectorInterface.GetVersionAsync() + ")");
        container = (WaveWindows.Controls.Toast.Container) null;
      }
      finally
      {
        sender1.IsInjectedText.Text = "Not Injected";
      }
    }

    private void Window_Closing(object sender, CancelEventArgs e)
    {
      this.WmiWatcher.Stop();
      this.SocketServer.Dispose();
    }

    private void EditorToggleButton_Click(object sender, RoutedEventArgs e)
    {
      this.SwitchPage(PageState.Editor);
    }

    private void ScriptCloudToggleButton_Click(object sender, RoutedEventArgs e)
    {
      this.SwitchPage(PageState.ScriptCloud);
    }

    private void SettingsToggleButton_Click(object sender, RoutedEventArgs e)
    {
      this.SwitchPage(PageState.Settings);
    }

    private void ManagerToggleButton_Click(object sender, RoutedEventArgs e)
    {
      this.SwitchOverlay(OverlayState.Manager);
    }

    private void LicenseToggleButton_Click(object sender, RoutedEventArgs e)
    {
      this.SwitchOverlay(OverlayState.License);
    }

    private void Border_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (e.ChangedButton != MouseButton.Left || e.ButtonState != MouseButtonState.Pressed)
        return;
      if (this.WindowState == WindowState.Maximized)
      {
        this.WindowState = WindowState.Normal;
        this.Top = this.PointToScreen(new Point(0.0, 0.0)).Y / 2.0 - this.ActualHeight / 6.0;
      }
      this.DragMove();
    }

    private void ExitButton_Click(object sender, RoutedEventArgs e) => Environment.Exit(0);

    private void MaximizeButton_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = this.WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
    }

    private void MinimizeButton_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = WindowState.Minimized;
    }

    private async void InputBox_PreviewKeyDown(object sender, KeyEventArgs e)
    {
      this.InputBox.ScrollToEnd();
      if (!e.IsDown || e.Key != Key.Return)
        return;
      if (this.Product == null)
        this.ToastNotification.Warning("You currently have no active memberships, thus the artificial intelligence is disabled.");
      else if (this.Product.Name == "freemium-wave")
        this.ToastNotification.Warning("You currently have a free membership, thus the artificial intelligence is disabled.");
      else
        this.ToastNotification.Error("Artificial Intelligence", "The artificial intelligence is currently disabled.");
    }

    private async void ExecuteButton_Click(object sender, RoutedEventArgs e)
    {
      WaveWindows.Controls.Editor.TabItem tab = this.EditorTabControl.SelectedItem as WaveWindows.Controls.Editor.TabItem;
      Monaco editor = this.EditorTabControl.CurrentEditor;
      if (editor == null)
      {
        tab = (WaveWindows.Controls.Editor.TabItem) null;
        editor = (Monaco) null;
      }
      else
      {
        if (this.SelectedClients.Count < 1)
          this.ToastNotification.Warning("Please select a client to execute the script.");
        foreach (string selectedClient in this.SelectedClients)
          await WaveWindows.Modules.Behaviour.ClientBehaviour.ExecuteScriptAsync(selectedClient, tab.Id, await editor.GetText());
        tab = (WaveWindows.Controls.Editor.TabItem) null;
        editor = (Monaco) null;
      }
    }

    private void ClearButton_Click(object sender, RoutedEventArgs e)
    {
      this.EditorTabControl.CurrentEditor.SetText("");
    }

    private async void SaveFileButton_Click(object sender, RoutedEventArgs e)
    {
      SaveFileDialog saveFileDialog1 = new SaveFileDialog();
      saveFileDialog1.Filter = "LuaU Files (*.luau)|*.luau|Lua Files (*.lua)|*.lua|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
      saveFileDialog1.Title = "WaveWindows - Save File";
      saveFileDialog1.DefaultExt = "luau";
      saveFileDialog1.AddExtension = true;
      SaveFileDialog saveFileDialog2 = saveFileDialog1;
      if (!saveFileDialog2.ShowDialog().GetValueOrDefault())
        return;
      Monaco currentEditor = this.EditorTabControl.CurrentEditor;
      string path = saveFileDialog2.FileName;
      System.IO.File.WriteAllText(path, await currentEditor.GetText());
      path = (string) null;
    }

    private void OpenFileButton_Click(object sender, RoutedEventArgs e)
    {
      OpenFileDialog openFileDialog1 = new OpenFileDialog();
      openFileDialog1.Filter = "LuaU Files (*.luau)|*.luau|Lua Files (*.lua)|*.lua|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
      openFileDialog1.Title = "WaveWindows - Open File";
      openFileDialog1.Multiselect = false;
      OpenFileDialog openFileDialog2 = openFileDialog1;
      if (!openFileDialog2.ShowDialog().GetValueOrDefault())
        return;
      this.EditorTabControl.CurrentEditor.SetText(System.IO.File.ReadAllText(openFileDialog2.FileName));
    }

    private void SidePanelButton_MouseDown(object sender, MouseButtonEventArgs e)
    {
      ThicknessAnimation thicknessAnimation1 = new ThicknessAnimation();
      thicknessAnimation1.To = new Thickness?(new Thickness(this.IsSidePanelShown ? -230.0 : 0.0, 0.0, 0.0, 0.0));
      thicknessAnimation1.Duration = (Duration) TimeSpan.FromSeconds(0.75);
      thicknessAnimation1.EasingFunction = (IEasingFunction) new QuarticEase();
      ThicknessAnimation animation1 = thicknessAnimation1;
      ThicknessAnimation thicknessAnimation2 = new ThicknessAnimation();
      thicknessAnimation2.To = new Thickness?(new Thickness(this.IsSidePanelShown ? 0.0 : 230.0, 0.0, 0.0, 0.0));
      thicknessAnimation2.Duration = (Duration) TimeSpan.FromSeconds(0.75);
      thicknessAnimation2.EasingFunction = (IEasingFunction) new QuarticEase();
      ThicknessAnimation animation2 = thicknessAnimation2;
      this.SidePanel.BeginAnimation(FrameworkElement.MarginProperty, (AnimationTimeline) animation1);
      this.EditorPanel.BeginAnimation(FrameworkElement.MarginProperty, (AnimationTimeline) animation2);
      this.IsSidePanelShown = !this.IsSidePanelShown;
    }

    private async void SearchBox_Loaded(object sender, RoutedEventArgs e)
    {
      try
      {
        this.SearchResult = await ScriptBloxInterface.Search("", 1);
        this.PopulateSearchResult(this.SearchResult);
      }
      catch
      {
        this.ToastNotification.Error("The search engine could not be initialized.");
      }
    }

    private async void SearchBox_KeyDown(object sender, KeyEventArgs e)
    {
      if (!e.IsDown || e.Key != Key.Return)
        return;
      this.SearchQuery = this.SearchBox.Text;
      if (string.IsNullOrEmpty(this.SearchQuery))
        return;
      try
      {
        this.SearchResult = await ScriptBloxInterface.Search(this.SearchQuery, 1);
        this.PopulateSearchResult(this.SearchResult);
      }
      catch
      {
        this.ToastNotification.Error("Unable to search for the specified query.");
      }
    }

    private void PreviousPageButton_Click(object sender, RoutedEventArgs e)
    {
      this.NavigateSearchResult(this.SearchResult, this.SearchResult.NextPage - 2);
    }

    private void NextPageButton_Click(object sender, RoutedEventArgs e)
    {
      this.NavigateSearchResult(this.SearchResult, this.SearchResult.NextPage);
    }

    private void SettingsExecutorToggleButton_Click(object sender, RoutedEventArgs e)
    {
      this.SettingsExecutorSection.BringIntoView();
    }

    private void SettingsEditorToggleButton_Click(object sender, RoutedEventArgs e)
    {
      this.SettingsEditorSection.BringIntoView();
    }

    private void SettingsArtificialIntelligenceToggleButton_Click(object sender, RoutedEventArgs e)
    {
      this.SettingsArtificialIntelligenceSection.BringIntoView();
    }

    private void ContinueOnStartUpCheckBox_Checked(object sender, CheckBoxChangedEvent e)
    {
      WaveWindows.Modules.Registry.Configuration.ContinueOnStartUp = e.Value;
    }

    private void TopMostCheckBox_Checked(object sender, CheckBoxChangedEvent e)
    {
      WaveWindows.Modules.Registry.Configuration.TopMost = e.Value;
      this.Topmost = e.Value;
    }

    private void RedirectCompilerErrorCheckBox_Checked(object sender, CheckBoxChangedEvent e)
    {
      WaveWindows.Modules.Registry.Configuration.RedirectCompilerError = e.Value;
    }

    private void UsePerformanceModeCheckBox_Checked(object sender, CheckBoxChangedEvent e)
    {
      WaveWindows.Modules.Registry.Configuration.UsePerformanceMode = e.Value;
    }

    private void RefreshRateSlider_Changed(object sender, SliderChangedEvent e)
    {
      WaveWindows.Modules.Registry.Configuration.RefreshRate = e.Value;
      foreach (Monaco allEditor in this.EditorTabControl.GetAllEditors())
        allEditor.SetBrowserFramerate(e.Value);
    }

    private void FontSizeSlider_Changed(object sender, SliderChangedEvent e)
    {
      WaveWindows.Modules.Registry.Configuration.FontSize = e.Value;
      this.EditorOptions.FontSize = e.Value;
      foreach (Monaco allEditor in this.EditorTabControl.GetAllEditors())
        allEditor.SetFontSize(e.Value);
    }

    private void MinimapCheckBox_Checked(object sender, CheckBoxChangedEvent e)
    {
      WaveWindows.Modules.Registry.Configuration.Minimap = e.Value;
      this.EditorOptions.Minimap.Enabled = e.Value;
      foreach (Monaco allEditor in this.EditorTabControl.GetAllEditors())
        allEditor.SetMinimap(e.Value);
    }

    private void InlayHintsCheckBox_Checked(object sender, CheckBoxChangedEvent e)
    {
      WaveWindows.Modules.Registry.Configuration.InlayHints = e.Value;
      this.EditorOptions.InlayHints.Enabled = e.Value;
      foreach (Monaco allEditor in this.EditorTabControl.GetAllEditors())
        allEditor.SetInlayHints(e.Value);
    }

    private void SendCurrentDocumentCheckBox_Checked(object sender, CheckBoxChangedEvent e)
    {
      WaveWindows.Modules.Registry.Configuration.SendCurrentDocument = e.Value;
    }

    private async void JoinNowButton_Click(object sender, RoutedEventArgs e)
    {
      if (string.IsNullOrEmpty(this.LicenseKeyBox.Text))
      {
        this.ToastNotification.Warning("Please provide a license key to redeem.");
      }
      else
      {
        try
        {
          this.ToggleLoading(true, true);
          await WaveInterface.RedeemAsync(this.Session, this.LicenseKeyBox.Text);
          this.User = await WaveInterface.GetUserAsync(this.Session);
          this.Product = this.User.Products.FirstOrDefault<Types.WaveAPI.Product>((Func<Types.WaveAPI.Product, bool>) (x => x.Name == "premium-wave")) ?? this.User.Products.FirstOrDefault<Types.WaveAPI.Product>((Func<Types.WaveAPI.Product, bool>) (x => x.Name == "freemium-wave")) ?? (Types.WaveAPI.Product) null;
          this.LoadUserData();
        }
        catch (Exception ex)
        {
          this.ToastNotification.Error(ex.Message);
        }
        finally
        {
          this.LicenseKeyBox.Text = string.Empty;
          this.ToggleLoading(false, true);
        }
      }
    }

    private void DurationText_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (this.Product != null)
        return;
      Process.Start("https://key.getwave.gg");
    }

    private void ManagerOverlay_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.HideManagerOrLicenseOverlay();
    }

    private void LicenseOverlay_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.HideManagerOrLicenseOverlay();
    }

    public void ShowUnhandledExceptionError(UnhandledExceptionErrorType type, string message)
    {
      this.UnhandledExceptionError.Show(this.BlurEffect, this.GetUnhandledExceptionErrorTitle(type), message);
    }

    private string GetUnhandledExceptionErrorTitle(UnhandledExceptionErrorType type)
    {
      switch (type)
      {
        case UnhandledExceptionErrorType.ApplicationError:
          return "Application Error";
        case UnhandledExceptionErrorType.SecurityError:
          return "Security Error";
        case UnhandledExceptionErrorType.RegistryError:
          return "Registry Error";
        default:
          throw new ArgumentException("GetUnhandledExceptionErrorTitle.UnhandledExceptionErrorType");
      }
    }

    private string GetInjectionMessage(InjectionStatus status, object data)
    {
      switch (status)
      {
        case InjectionStatus.Waiting:
          return "Waiting for the client to be ready.";
        case InjectionStatus.Injecting:
          return "Attempting to inject the client.";
        case InjectionStatus.Failed:
          return string.Format("The Injector process has exited with a non-zero exit code. ({0})", data);
        case InjectionStatus.Outdated:
          return "The Injector is currently outdated. Please try again later.";
        default:
          return string.Empty;
      }
    }

    private void HandleInjectionCallback(InjectionStatus status, object data)
    {
      this.Dispatcher.Invoke((Action) (() =>
      {
        string injectionMessage = this.GetInjectionMessage(status, data);
        if (string.IsNullOrEmpty(injectionMessage))
          return;
        this.ToastNotification.Info(injectionMessage);
      }));
    }

    private async void OnClientBehaviourAdded(Types.ClientBehaviour.ClientIdentity identity)
    {
      if (identity == null)
        ;
      else
      {
        ImageSource imageSource1;
        if (string.IsNullOrEmpty(identity.Player.Id) || identity.Player.Id == "0")
          imageSource1 = (ImageSource) null;
        else
          imageSource1 = await this.GetClientAvatarHeadshot(identity.Player.Id);
        ImageSource imageSource2 = imageSource1;
        Client client1 = new Client();
        client1.Id = identity.Process.Id;
        client1.Player = identity.Player.Name;
        client1.Game = identity.Game.Name;
        client1.Image = imageSource2;
        client1.Margin = new Thickness(0.0, 0.0, 0.0, 10.0);
        Client client = client1;
        client.Checked += (EventHandler<string>) ((sender, e) =>
        {
          if (this.SelectedClients.Contains(client.Id))
            this.SelectedClients.Remove(client.Id);
          else
            this.SelectedClients.Add(client.Id);
        });
        if (this.SelectedClients.Count < 1)
          client.IsChecked = true;
        this.ClientList.Children.Add((UIElement) client);
      }
    }

    private async void OnClientBehaviourUpdated(Types.ClientBehaviour.ClientIdentity identity)
    {
      Client client;
      if (identity == null)
      {
        client = (Client) null;
      }
      else
      {
        client = this.ClientList.Children.OfType<Client>().FirstOrDefault<Client>((Func<Client, bool>) (x => x.Id == identity.Process.Id));
        if (client == null)
        {
          client = (Client) null;
        }
        else
        {
          ImageSource imageSource1;
          if (string.IsNullOrEmpty(identity.Player.Id) || identity.Player.Id == "0")
            imageSource1 = (ImageSource) null;
          else
            imageSource1 = await this.GetClientAvatarHeadshot(identity.Player.Id);
          ImageSource imageSource2 = imageSource1;
          client.Player = identity.Player.Name;
          client.Game = identity.Game.Name;
          client.Image = imageSource2;
          client = (Client) null;
        }
      }
    }

    private void OnClientBehaviourRemoved(string id)
    {
      if (string.IsNullOrEmpty(id))
        return;
      Client element = this.ClientList.Children.OfType<Client>().FirstOrDefault<Client>((Func<Client, bool>) (x => x.Id == id));
      if (element == null)
        return;
      if (this.SelectedClients.Contains(element.Id))
        this.SelectedClients.Remove(element.Id);
      this.ClientList.Children.Remove((UIElement) element);
    }

    private void OnClientBehaviourScript(Types.ClientBehaviour.ClientScript script)
    {
    }

    private async void OnClientBehaviourError(
      string OpCode,
      Types.ClientBehaviour.ClientError error)
    {
      if (error == null)
        return;
      switch (OpCode)
      {
        case "OP_AUTH":
          if (error.ClearSession)
            WaveWindows.Modules.Registry.Configuration.Session = "";
          this.ToastNotification.Error(string.Format("Authentication Failed ({0})", (object) error.Code), error.Message);
          await Task.Delay(5000);
          this.BackToLogin();
          break;
        case "OP_ERROR":
          string message = error.Message;
          int num1 = message.IndexOf(':');
          int num2 = message.IndexOf(':', num1 + 1);
          string lineInfo = message.Substring(num1 + 1, num2 - num1 - 1).Trim();
          string Description = message.Substring(num2 + 1).Trim();
          WaveWindows.Controls.Editor.TabItem tab = this.EditorTabControl.SelectedItem as WaveWindows.Controls.Editor.TabItem;
          this.ToastNotification.Error("Compiler Error", Description, string.Format("{0}:{1}", tab.Header, (object) lineInfo), (Action) (() => this.EditorTabControl.SelectById(tab.Id)?.GoToLine(int.Parse(lineInfo))));
          break;
      }
    }

    private async Task<ImageSource> GetClientAvatarHeadshot(string playerId)
    {
      RestResponse restResponse = await this.RobloxThumbnailApi.ExecuteAsync(RestRequestExtensions.AddParameter(RestRequestExtensions.AddParameter(RestRequestExtensions.AddParameter(RestRequestExtensions.AddParameter(RestRequestExtensions.AddParameter(new RestRequest("users/avatar-headshot", (Method) 0), "userIds", playerId, true), "size", "100x100", true), "format", "Png", true), "isCircular", "false", true), "accept", "application/json", true), new CancellationToken());
      string str = ((RestResponseBase) restResponse).StatusCode == HttpStatusCode.OK ? ((RestResponseBase) restResponse).Content : throw new HttpRequestException("RobloxThumbnailApi");
      Types.RobloxThumbnail.ThumbnailResponse thumbnailResponse = !string.IsNullOrEmpty(str) ? JsonConvert.DeserializeObject<Types.RobloxThumbnail.ThumbnailResponse>(str) : throw new NullReferenceException("ThumbnailResponse");
      if (thumbnailResponse == null)
        throw new NullReferenceException("ThumbnailResponse");
      if (thumbnailResponse.Data.Count < 1)
        throw new NullReferenceException("ThumbnailResponse");
      Types.RobloxThumbnail.ThumbnailData thumbnailData = thumbnailResponse.Data.FirstOrDefault<Types.RobloxThumbnail.ThumbnailData>() ?? throw new NullReferenceException("Avatar");
      if (string.IsNullOrEmpty(thumbnailData.Image))
      {
        this.ToastNotification.Error("The avatar profile could not be fetched; it may be private or contain deleted items.");
        return (ImageSource) null;
      }
      BitmapImage clientAvatarHeadshot = new BitmapImage();
      clientAvatarHeadshot.BeginInit();
      clientAvatarHeadshot.UriSource = new Uri(thumbnailData.Image);
      clientAvatarHeadshot.EndInit();
      return (ImageSource) clientAvatarHeadshot;
    }

    private void LoadCurrentWorkspace(string path)
    {
      List<string> stringList = new List<string>();
      string path1 = Path.Combine(Path.GetTempPath(), path);
      if (!Directory.Exists(path1))
        return;
      foreach (string file in Directory.GetFiles(path1, "*", SearchOption.AllDirectories))
        stringList.Add(file);
      foreach (string path2 in stringList)
      {
        string Content = System.IO.File.ReadAllText(path2);
        if (string.IsNullOrEmpty(Content))
          return;
        string fileName = Path.GetFileName(path2);
        if (string.IsNullOrEmpty(Path.GetExtension(path2)))
          fileName = Content.Split('\n', '\r')[0];
        this.EditorTabControl.AddTab(fileName, Content);
      }
      if (this.EditorTabControl.Items.Count > 1)
        this.EditorTabControl.Items.RemoveAt(0);
      Directory.Delete(path1, true);
    }

    private async void SaveCurrentWorkspace(string path)
    {
      WaveWindows.Controls.Editor.TabItem[] allTabs = this.EditorTabControl.GetAllTabs();
      string directory = Path.Combine(Path.GetTempPath(), path);
      if (!Directory.Exists(directory))
        Directory.CreateDirectory(directory);
      WaveWindows.Controls.Editor.TabItem[] tabItemArray = allTabs;
      for (int index = 0; index < tabItemArray.Length; ++index)
      {
        WaveWindows.Controls.Editor.TabItem tabItem = tabItemArray[index];
        string header = tabItem.Header as string;
        Monaco editor = tabItem.GetEditor();
        if (!header.EndsWith(".luau") || !header.EndsWith(".lua") || !header.EndsWith(".txt"))
          header = Cryptography.SHA1.Compute(await editor.GetText());
        string path1 = Path.Combine(directory, header);
        System.IO.File.WriteAllText(path1, await editor.GetText());
        path1 = (string) null;
        editor = (Monaco) null;
      }
      tabItemArray = (WaveWindows.Controls.Editor.TabItem[]) null;
      directory = (string) null;
    }

    private string LoadMessageCodeBlocks(string message)
    {
      MatchCollection matchCollection = Regex.Matches(message, "```lua\\s*([^`]+)\\s*```", RegexOptions.Singleline);
      string str = message;
      for (int i = 0; i < matchCollection.Count; ++i)
      {
        string Content = matchCollection[i].Groups[1].Value;
        str = str.Replace(matchCollection[i].Value, string.Format("Reference {0}.lua", (object) this.References));
        this.EditorTabControl.AddTab(string.Format("Reference {0}.lua", (object) this.References), Content);
        ++this.References;
      }
      return str.Trim();
    }

    private void LoadUserData()
    {
      if (this.Product == null)
      {
        this.ToastNotification.Warning("You currently have no active memberships, thus the initial injection procedure cannot be performed.");
        this.ToggleAds(true);
      }
      else
      {
        this.DurationText.Text = this.NormalizeTimestamp(this.Product.Timestamp);
        this.MembershipText.Text = this.Product.Name == "premium-wave" ? "Wave Premium" : "Wave Free";
        this.ToggleAds(this.Product.Name == "freemium-wave");
      }
    }

    private string NormalizeTimestamp(long timestamp)
    {
      return DateTimeOffset.FromUnixTimeMilliseconds(timestamp).UtcDateTime.ToString("MMMM dd, yyyy");
    }

    private void LoadMessages()
    {
      foreach (Types.WaveAPI.Message message in this.Messages)
      {
        bool flag = message.Role == "user";
        this.MessageList.Items.Add((object) new WaveWindows.Controls.Message()
        {
          Text = message.Content,
          Reverse = flag
        });
      }
    }

    private void ToggleLoading(bool show, bool hasOverlay = false)
    {
      DoubleAnimation doubleAnimation = new DoubleAnimation();
      doubleAnimation.To = new double?((double) (show ? 1 : 0));
      doubleAnimation.Duration = (Duration) TimeSpan.FromSeconds(0.25);
      QuarticEase quarticEase = new QuarticEase();
      quarticEase.EasingMode = show ? EasingMode.EaseIn : EasingMode.EaseOut;
      doubleAnimation.EasingFunction = (IEasingFunction) quarticEase;
      DoubleAnimation animation = doubleAnimation;
      this.LoadingOverlay.Background = !hasOverlay ? (Brush) Brushes.Black : (Brush) Brushes.Transparent;
      this.LoadingOverlay.IsHitTestVisible = show;
      this.BlurEffect.BeginAnimation(BlurEffect.RadiusProperty, (AnimationTimeline) animation);
      this.LoadingOverlay.BeginAnimation(UIElement.OpacityProperty, (AnimationTimeline) animation);
    }

    private void ToggleAds(bool show)
    {
      this.AdContainer.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
      this.MinHeight = show ? 570.0 : 446.0;
      this.Background.Margin = new Thickness(4.0, 0.0, 4.0, show ? 124.0 : 0.0);
      this.ManagerOverlayContainer.Margin = new Thickness(4.0, 0.0, 4.0, show ? 124.0 : 0.0);
      this.LicenseOverlayContainer.Margin = new Thickness(4.0, 0.0, 4.0, show ? 124.0 : 0.0);
      this.ToastNotification.Margin = new Thickness(4.0, 25.0, 4.0, show ? 124.0 : 0.0);
      this.UnhandledExceptionError.Margin = new Thickness(4.0, 0.0, 4.0, show ? 124.0 : 0.0);
      this.LoadingOverlay.Margin = new Thickness(4.0, 0.0, 4.0, show ? 124.0 : 0.0);
      this.Left = SystemParameters.PrimaryScreenWidth / 2.0 - this.Width / 2.0;
      this.Top = SystemParameters.PrimaryScreenHeight / 2.0 - this.Height / 2.0;
    }

    private void OnceReady()
    {
      this.WmiWatcher.Once((Action<List<Instance>>) (async processes =>
      {
        MainWindow mainWindow = this;
        if (processes.Count < 1)
          return;
        mainWindow.ToastNotification.Info("Please wait while we attempt to reconnect to the client.");
        List<Types.ClientBehaviour.ClientIdentity> source = await WaveWindows.Modules.Behaviour.ClientBehaviour.WaitFor<Types.ClientBehaviour.ClientIdentity>("OP_IDENTIFY", 3);
        if (source.Count > 0)
          mainWindow.ToastNotification.Success(string.Format("The clients has been successfully reconnected. ({0})", (object) source.Count));
        if (!mainWindow.IsClientReady)
          return;
        foreach (Instance process1 in processes)
        {
          Instance process = process1;
          if (source.FirstOrDefault<Types.ClientBehaviour.ClientIdentity>((Func<Types.ClientBehaviour.ClientIdentity, bool>) (x => x.Process.Id == process.Process.Id.ToString())) != null)
            break;
          process.Inject(new Action<InjectionStatus, object>(mainWindow.HandleInjectionCallback));
        }
      }));
    }

    private void BackToLogin()
    {
      DoubleAnimation doubleAnimation = new DoubleAnimation();
      doubleAnimation.To = new double?(0.0);
      doubleAnimation.Duration = (Duration) TimeSpan.FromSeconds(0.25);
      QuarticEase quarticEase = new QuarticEase();
      quarticEase.EasingMode = EasingMode.EaseOut;
      doubleAnimation.EasingFunction = (IEasingFunction) quarticEase;
      DoubleAnimation animation = doubleAnimation;
      animation.Completed += (EventHandler) ((sender, e) =>
      {
        new LoginWindow().Show();
        this.Close();
      });
      this.BeginAnimation(UIElement.OpacityProperty, (AnimationTimeline) animation);
    }

    private void SwitchPage(PageState PageState)
    {
      if (this.CurrentPageSelection == PageState)
        return;
      this.EditorToggleButton.IsChecked = new bool?(false);
      this.ScriptCloudToggleButton.IsChecked = new bool?(false);
      this.SettingsToggleButton.IsChecked = new bool?(false);
      switch (PageState)
      {
        case PageState.Editor:
          this.MoveSelectionBar(51.0);
          this.CurrentPageSelection = PageState.Editor;
          break;
        case PageState.ScriptCloud:
          this.MoveSelectionBar(105.0);
          this.CurrentPageSelection = PageState.ScriptCloud;
          break;
        case PageState.Settings:
          this.MoveSelectionBar(159.0);
          this.CurrentPageSelection = PageState.Settings;
          break;
        default:
          throw new NotImplementedException();
      }
    }

    private void MoveSelectionBar(double Offset)
    {
      ThicknessAnimation thicknessAnimation = new ThicknessAnimation();
      thicknessAnimation.To = new Thickness?(new Thickness(0.0, Offset, 0.0, 0.0));
      thicknessAnimation.Duration = (Duration) TimeSpan.FromSeconds(1.5);
      thicknessAnimation.EasingFunction = (IEasingFunction) new ElasticEase()
      {
        Springiness = 17.5
      };
      ThicknessAnimation animation = thicknessAnimation;
      this.PageSelectionBar.BeginAnimation(FrameworkElement.MarginProperty, (AnimationTimeline) animation);
    }

    private void SwitchOverlay(OverlayState OverlayState)
    {
      if (this.CurrentOverlaySelection == OverlayState)
        return;
      DoubleAnimation doubleAnimation1 = new DoubleAnimation();
      doubleAnimation1.To = new double?(2.0);
      doubleAnimation1.Duration = (Duration) TimeSpan.FromSeconds(0.25);
      doubleAnimation1.EasingFunction = (IEasingFunction) new QuarticEase();
      DoubleAnimation animation1 = doubleAnimation1;
      DoubleAnimation doubleAnimation2 = new DoubleAnimation();
      doubleAnimation2.To = new double?(1.0);
      doubleAnimation2.Duration = (Duration) TimeSpan.FromSeconds(0.25);
      DoubleAnimation animation2 = doubleAnimation2;
      switch (OverlayState)
      {
        case OverlayState.Manager:
          this.ManagerOverlayContainer.IsHitTestVisible = true;
          this.ManagerOverlayContainer.BeginAnimation(UIElement.OpacityProperty, (AnimationTimeline) animation2);
          break;
        case OverlayState.License:
          this.LicenseOverlayContainer.IsHitTestVisible = true;
          this.LicenseOverlayContainer.BeginAnimation(UIElement.OpacityProperty, (AnimationTimeline) animation2);
          break;
      }
      this.BlurEffect.BeginAnimation(BlurEffect.RadiusProperty, (AnimationTimeline) animation1);
      this.CurrentOverlaySelection = OverlayState;
    }

    private async void PopulateSearchResult(SearchResult result)
    {
      MainWindow mainWindow1 = this;
      if (result == null)
        return;
      int currentPage = result.NextPage - 1;
      if (currentPage == -1)
        currentPage = result.Scripts.Count <= 0 ? 0 : 1;
      mainWindow1.ShowOrHideScriptCloudNoResult(result.Scripts.Count < 1);
      mainWindow1.ShowOrHideScriptCloudNavigationButtons(result, currentPage);
      mainWindow1.CurrentPageText.Text = string.Format("{0} of {1}", (object) currentPage, (object) result.TotalPages);
      mainWindow1.ScriptList.Children.Clear();
      foreach (WaveWindows.Interfaces.Script script3 in result.Scripts)
      {
        MainWindow mainWindow = mainWindow1;
        WaveWindows.Interfaces.Script item = script3;
        WaveWindows.Controls.Card.Script script1 = new WaveWindows.Controls.Card.Script();
        script1.Title = item.Title;
        script1.Description = item.Game.Name;
        WaveWindows.Controls.Card.Script script2 = script1;
        script2.ImageSource = await mainWindow1.GetImageAsync(item.Game.Image);
        WaveWindows.Controls.Card.Script element = script1;
        script2 = (WaveWindows.Controls.Card.Script) null;
        script1 = (WaveWindows.Controls.Card.Script) null;
        element.MouseDown += (MouseButtonEventHandler) (async (sender, e) =>
        {
          WaveWindows.Interfaces.Script script4 = await ScriptBloxInterface.GetScript(item);
          if (!script4.Verified)
            mainWindow.ToastNotification.Warning("Caution: Security Alert", "The selected context has not been verified.");
          mainWindow.SwitchPage(PageState.Editor);
          mainWindow.EditorTabControl.AddTab(item.Title, script4.Source);
        });
        mainWindow1.ScriptList.Children.Add((UIElement) element);
      }
    }

    private async void NavigateSearchResult(SearchResult result, int page)
    {
      if (result == null || page < 1)
        return;
      SearchResult result1 = await ScriptBloxInterface.Search(this.SearchQuery, page);
      this.PopulateSearchResult(result1);
      this.SearchResult = result1;
    }

    private void ShowOrHideScriptCloudNoResult(bool Show)
    {
      DoubleAnimation doubleAnimation = new DoubleAnimation();
      doubleAnimation.To = new double?((double) (Show ? 1 : 0));
      doubleAnimation.Duration = (Duration) TimeSpan.FromSeconds(0.25);
      doubleAnimation.EasingFunction = (IEasingFunction) new QuarticEase();
      DoubleAnimation animation = doubleAnimation;
      this.NoResultSection.BeginAnimation(UIElement.OpacityProperty, (AnimationTimeline) animation);
    }

    private void ShowOrHideScriptCloudNavigationButtons(SearchResult result, int currentPage)
    {
      if (result == null)
        return;
      bool flag1 = currentPage > 1;
      bool flag2 = currentPage < result.TotalPages;
      DoubleAnimation doubleAnimation1 = new DoubleAnimation();
      doubleAnimation1.To = new double?(flag1 ? 1.0 : 0.5);
      doubleAnimation1.Duration = (Duration) TimeSpan.FromSeconds(0.25);
      doubleAnimation1.EasingFunction = (IEasingFunction) new QuarticEase();
      DoubleAnimation animation1 = doubleAnimation1;
      DoubleAnimation doubleAnimation2 = new DoubleAnimation();
      doubleAnimation2.To = new double?(flag2 ? 1.0 : 0.5);
      doubleAnimation2.Duration = (Duration) TimeSpan.FromSeconds(0.25);
      doubleAnimation2.EasingFunction = (IEasingFunction) new QuarticEase();
      DoubleAnimation animation2 = doubleAnimation2;
      this.PreviousPageButton.IsHitTestVisible = flag1;
      this.NextPageButton.IsHitTestVisible = flag2;
      this.PreviousPageButton.BeginAnimation(UIElement.OpacityProperty, (AnimationTimeline) animation1);
      this.NextPageButton.BeginAnimation(UIElement.OpacityProperty, (AnimationTimeline) animation2);
    }

    private async Task<ImageSource> GetImageAsync(string image)
    {
      string imageUrl = ScriptBloxInterface.GetImageUrl(image);
      return imageUrl.EndsWith(".webp") ? ScriptBloxInterface.ToImage("https://tr.rbxcdn.com/3e86507fbb9beb6431c5747e5596b06d/768/432/Image/Png") : ScriptBloxInterface.ToImage(imageUrl);
    }

    private void HideManagerOrLicenseOverlay()
    {
      if (this.CurrentOverlaySelection != OverlayState.Manager && this.CurrentOverlaySelection != OverlayState.License)
        return;
      DoubleAnimation doubleAnimation1 = new DoubleAnimation();
      doubleAnimation1.To = new double?(0.0);
      doubleAnimation1.Duration = (Duration) TimeSpan.FromSeconds(0.5);
      doubleAnimation1.EasingFunction = (IEasingFunction) new QuarticEase();
      DoubleAnimation animation1 = doubleAnimation1;
      DoubleAnimation doubleAnimation2 = new DoubleAnimation();
      doubleAnimation2.To = new double?(0.0);
      doubleAnimation2.Duration = (Duration) TimeSpan.FromSeconds(0.25);
      DoubleAnimation animation2 = doubleAnimation2;
      switch (this.CurrentOverlaySelection)
      {
        case OverlayState.Manager:
          this.ManagerToggleButton.IsChecked = new bool?(false);
          this.ManagerOverlayContainer.IsHitTestVisible = false;
          this.ManagerOverlayContainer.BeginAnimation(UIElement.OpacityProperty, (AnimationTimeline) animation2);
          break;
        case OverlayState.License:
          this.LicenseToggleButton.IsChecked = new bool?(false);
          this.LicenseOverlayContainer.IsHitTestVisible = false;
          this.LicenseOverlayContainer.BeginAnimation(UIElement.OpacityProperty, (AnimationTimeline) animation2);
          break;
      }
      this.BlurEffect.BeginAnimation(BlurEffect.RadiusProperty, (AnimationTimeline) animation1);
      this.CurrentOverlaySelection = OverlayState.None;
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/WaveWindows;component/mainwindow.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler)
    {
      return Delegate.CreateDelegate(delegateType, (object) this, handler);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((FrameworkElement) target).Loaded += new RoutedEventHandler(this.Window_Loaded);
          ((Window) target).Closing += new CancelEventHandler(this.Window_Closing);
          break;
        case 2:
          this.Background = (Border) target;
          break;
        case 3:
          this.BlurEffect = (BlurEffect) target;
          break;
        case 4:
          this.EditorToggleButton = (ToggleButton) target;
          this.EditorToggleButton.Click += new RoutedEventHandler(this.EditorToggleButton_Click);
          break;
        case 5:
          this.ScriptCloudToggleButton = (ToggleButton) target;
          this.ScriptCloudToggleButton.Click += new RoutedEventHandler(this.ScriptCloudToggleButton_Click);
          break;
        case 6:
          this.SettingsToggleButton = (ToggleButton) target;
          this.SettingsToggleButton.Click += new RoutedEventHandler(this.SettingsToggleButton_Click);
          break;
        case 7:
          this.ManagerToggleButton = (ToggleButton) target;
          this.ManagerToggleButton.Click += new RoutedEventHandler(this.ManagerToggleButton_Click);
          break;
        case 8:
          this.LicenseToggleButton = (ToggleButton) target;
          this.LicenseToggleButton.Click += new RoutedEventHandler(this.LicenseToggleButton_Click);
          break;
        case 9:
          this.PageSelectionBar = (Border) target;
          break;
        case 10:
          ((UIElement) target).MouseDown += new MouseButtonEventHandler(this.Border_MouseDown);
          break;
        case 11:
          this.IsInjectedText = (TextBlock) target;
          break;
        case 12:
          this.ExitButton = (WaveWindows.Controls.Button) target;
          break;
        case 13:
          this.MaximizeButton = (WaveWindows.Controls.Button) target;
          break;
        case 14:
          this.MinimizeButton = (WaveWindows.Controls.Button) target;
          break;
        case 15:
          this.EditorPage = (Border) target;
          break;
        case 16:
          this.SidePanel = (Border) target;
          break;
        case 17:
          this.MessageList = (ListView) target;
          break;
        case 18:
          this.InputBox = (WaveWindows.Controls.InputBox) target;
          break;
        case 19:
          this.EditorPanel = (Border) target;
          break;
        case 20:
          this.EditorTabControl = (WaveWindows.Controls.Editor.TabControl) target;
          break;
        case 21:
          this.ExecuteButton = (WaveWindows.Controls.Button) target;
          break;
        case 22:
          this.ClearButton = (WaveWindows.Controls.Button) target;
          break;
        case 23:
          this.SaveFileButton = (WaveWindows.Controls.Button) target;
          break;
        case 24:
          this.OpenFileButton = (WaveWindows.Controls.Button) target;
          break;
        case 25:
          this.SidePanelButton = (Border) target;
          this.SidePanelButton.MouseDown += new MouseButtonEventHandler(this.SidePanelButton_MouseDown);
          break;
        case 26:
          this.ScriptCloudPage = (Border) target;
          break;
        case 27:
          this.SearchBox = (WaveWindows.Controls.InputBox) target;
          break;
        case 28:
          this.PreviousPageButton = (WaveWindows.Controls.Button) target;
          break;
        case 29:
          this.CurrentPageText = (TextBlock) target;
          break;
        case 30:
          this.NextPageButton = (WaveWindows.Controls.Button) target;
          break;
        case 31:
          this.ScriptList = (WrapPanel) target;
          break;
        case 32:
          this.NoResultSection = (Grid) target;
          break;
        case 33:
          this.SettingsPage = (Border) target;
          break;
        case 34:
          this.SettingsExecutorToggleButton = (WaveWindows.Controls.Button) target;
          break;
        case 35:
          this.SettingsEditorToggleButton = (WaveWindows.Controls.Button) target;
          break;
        case 36:
          this.SettingsArtificialIntelligenceToggleButton = (WaveWindows.Controls.Button) target;
          break;
        case 37:
          this.SettingsExecutorSection = (Grid) target;
          break;
        case 38:
          this.ContinueOnStartUpCheckBox = (WaveWindows.Controls.Settings.CheckBox) target;
          break;
        case 39:
          this.TopMostCheckBox = (WaveWindows.Controls.Settings.CheckBox) target;
          break;
        case 40:
          this.RedirectCompilerErrorCheckBox = (WaveWindows.Controls.Settings.CheckBox) target;
          break;
        case 41:
          this.UsePerformanceModeCheckBox = (WaveWindows.Controls.Settings.CheckBox) target;
          break;
        case 42:
          this.SettingsEditorSection = (Grid) target;
          break;
        case 43:
          this.RefreshRateSlider = (WaveWindows.Controls.Settings.Slider) target;
          break;
        case 44:
          this.FontSizeSlider = (WaveWindows.Controls.Settings.Slider) target;
          break;
        case 45:
          this.MinimapCheckBox = (WaveWindows.Controls.Settings.CheckBox) target;
          break;
        case 46:
          this.InlayHintsCheckBox = (WaveWindows.Controls.Settings.CheckBox) target;
          break;
        case 47:
          this.SettingsArtificialIntelligenceSection = (Grid) target;
          break;
        case 48:
          this.SendCurrentDocumentCheckBox = (WaveWindows.Controls.Settings.CheckBox) target;
          break;
        case 49:
          this.ManagerOverlayContainer = (Grid) target;
          break;
        case 50:
          this.ManagerOverlay = (Border) target;
          this.ManagerOverlay.MouseDown += new MouseButtonEventHandler(this.ManagerOverlay_MouseDown);
          break;
        case 51:
          this.ClientList = (StackPanel) target;
          break;
        case 52:
          this.LicenseOverlayContainer = (Grid) target;
          break;
        case 53:
          this.LicenseOverlay = (Border) target;
          this.LicenseOverlay.MouseDown += new MouseButtonEventHandler(this.LicenseOverlay_MouseDown);
          break;
        case 54:
          this.DurationText = (TextBlock) target;
          this.DurationText.MouseDown += new MouseButtonEventHandler(this.DurationText_MouseDown);
          break;
        case 55:
          this.MembershipText = (TextBlock) target;
          break;
        case 56:
          this.LicenseKeyBox = (WaveWindows.Controls.InputBox) target;
          break;
        case 57:
          this.JoinNowButton = (WaveWindows.Controls.Button) target;
          break;
        case 58:
          this.LoadingOverlay = (Border) target;
          break;
        case 59:
          this.LoadingCircle = (Border) target;
          break;
        case 60:
          this.SubmitButtonRotateTransform = (RotateTransform) target;
          break;
        case 61:
          this.ToastNotification = (WaveWindows.Controls.Toast.Container) target;
          break;
        case 62:
          this.UnhandledExceptionError = (UnhandledExceptionError) target;
          break;
        case 63:
          this.AdContainer = (Border) target;
          break;
        case 64:
          this.AdImage = (ImageBrush) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
