﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.LoginWindow
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using WaveWindows.Controls;
using WaveWindows.Interfaces;
using WaveWindows.Modules;

#nullable disable
namespace WaveWindows
{
  public partial class LoginWindow : Window, IComponentConnector
  {
    private bool IsLoading;
    private PageState CurrentPageState = PageState.Login;
    internal Border Background;
    internal BlurEffect BlurEffect;
    internal TextBlock FirstNavigationButtonText;
    internal System.Windows.Controls.Button SecondNavigationButton;
    internal TextBlock SecondNavigationButtonText;
    internal TextBlock SecondNavigationText;
    internal TextBlock SecondNavigationTextButton;
    internal TextBlock FirstNavigationText;
    internal TextBlock FirstNavigationTextButton;
    internal InputBox UsernameBox;
    internal InputBox EmailBox;
    internal SecureTextBox PasswordBox;
    internal TextBlock RecoverPasswordButton;
    internal System.Windows.Controls.Button SubmitButton;
    internal Border LoadingCircle;
    internal RotateTransform SubmitButtonRotateTransform;
    internal TextBlock SubmitText;
    internal WaveWindows.Controls.Toast.Container ToastNotification;
    internal UnhandledExceptionError UnhandledExceptionError;
    private bool _contentLoaded;

    public LoginWindow() => this.InitializeComponent();

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      Initializer.Once();
      this.UsernameBox.Text = Registry.Configuration.LastUsername;
      if (string.IsNullOrEmpty(Registry.Configuration.Session))
        return;
      this.ToastNotification.Info("Click Me", "Would you like to continue with the last session?", (Action) (() => this.OpenMainWindow(Registry.Configuration.Session)));
    }

    private void Background_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (e.ChangedButton != MouseButton.Left || e.ButtonState != MouseButtonState.Pressed)
        return;
      this.DragMove();
    }

    private void SecondNavigationButton_Click(object sender, RoutedEventArgs e)
    {
      this.SwitchPage();
    }

    private void SecondNavigationTextButton_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.SwitchPage();
    }

    private void FirstNavigationTextButton_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.SwitchPage();
    }

    private void SwitchPage()
    {
      if (this.CurrentPageState == PageState.Login)
      {
        this.FirstNavigationButtonText.Text = "Sign Up";
        this.SecondNavigationButtonText.Text = "Login";
        this.FirstNavigationText.Visibility = Visibility.Visible;
        this.SecondNavigationText.Visibility = Visibility.Collapsed;
        this.UsernameBox.Placeholder = "Username";
        this.EmailBox.Visibility = Visibility.Visible;
        this.SubmitText.Text = "Sign Up";
        this.CurrentPageState = PageState.Register;
      }
      else
      {
        this.FirstNavigationButtonText.Text = "Sign In";
        this.SecondNavigationButtonText.Text = "Register";
        this.FirstNavigationText.Visibility = Visibility.Collapsed;
        this.SecondNavigationText.Visibility = Visibility.Visible;
        this.UsernameBox.Placeholder = "Username or Email";
        this.EmailBox.Visibility = Visibility.Collapsed;
        this.SubmitText.Text = "Sign In";
        this.CurrentPageState = PageState.Login;
      }
    }

    private void RecoverPasswordButton_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.RequestResetPassword();
    }

    private void SubmitButton_Click(object sender, RoutedEventArgs e)
    {
      this.ShowOrHideLoading();
      if (this.CurrentPageState == PageState.Login)
        this.Login();
      else
        this.Register();
      Registry.Configuration.LastUsername = this.UsernameBox.Text;
    }

    private async void Login()
    {
      LoginWindow loginWindow = this;
      try
      {
        if (loginWindow.UsernameBox.Text.Length < 3 || loginWindow.UsernameBox.Text.Length > 256)
          throw new Exception("Username must be between 3 and 32 characters.");
        if (loginWindow.PasswordBox.Password.Length < 6 || loginWindow.PasswordBox.Password.Length > 96)
          throw new Exception("Password must be between 6 and 96 characters.");
        Registry registry = Registry.Configuration;
        registry.Session = await WaveInterface.Login(loginWindow.UsernameBox.Text, loginWindow.PasswordBox.Password);
        registry = (Registry) null;
        loginWindow.OpenMainWindow(Registry.Configuration.Session);
      }
      catch (Exception ex)
      {
        if (ex.Message.StartsWith("Please verify"))
        {
          // ISSUE: reference to a compiler-generated method
          loginWindow.ToastNotification.Info("Please verify your email before continuing. Click here to resend the email verification.", new Action(loginWindow.\u003CLogin\u003Eb__11_0));
        }
        else
          loginWindow.ToastNotification.Error(ex.Message);
        loginWindow.ShowOrHideLoading();
      }
    }

    private async void Register()
    {
      try
      {
        if (this.UsernameBox.Text.Length < 3 || this.UsernameBox.Text.Length > 16)
          throw new Exception("Username must be between 3 and 16 characters.");
        if (this.PasswordBox.Password.Length < 6 || this.PasswordBox.Password.Length > 96)
          throw new Exception("Password must be between 6 and 96 characters.");
        if (!Regex.IsMatch(this.EmailBox.Text, "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"))
          throw new Exception("The provided email is malformed.");
        await WaveInterface.Register(this.UsernameBox.Text, this.EmailBox.Text, this.PasswordBox.Password);
        this.ToastNotification.Success("Your account has been created successfully. Please verify your email address to continue.");
      }
      catch (Exception ex)
      {
        this.ToastNotification.Error(ex.Message);
      }
      finally
      {
        this.ShowOrHideLoading();
      }
    }

    private async void RequestResetPassword()
    {
      try
      {
        await WaveInterface.RequestPasswordReset(this.CurrentPageState == PageState.Login ? this.UsernameBox.Text : this.EmailBox.Text);
        this.ToastNotification.Success("A password reset email has been sent. Please check your inbox to complete the reset process.");
      }
      catch (Exception ex)
      {
        this.ToastNotification.Error(ex.Message);
      }
    }

    private void OpenMainWindow(string session)
    {
      DoubleAnimation doubleAnimation = new DoubleAnimation();
      doubleAnimation.To = new double?(0.0);
      doubleAnimation.Duration = (Duration) TimeSpan.FromSeconds(0.25);
      QuarticEase quarticEase = new QuarticEase();
      quarticEase.EasingMode = EasingMode.EaseOut;
      doubleAnimation.EasingFunction = (IEasingFunction) quarticEase;
      DoubleAnimation animation = doubleAnimation;
      animation.Completed += (EventHandler) ((s, e) =>
      {
        new MainWindow(session).Show();
        this.Close();
      });
      this.Background.BeginAnimation(UIElement.OpacityProperty, (AnimationTimeline) animation);
    }

    private void ShowOrHideLoading()
    {
      if (this.IsLoading)
      {
        this.SubmitButton.IsHitTestVisible = true;
        this.LoadingCircle.Visibility = Visibility.Collapsed;
        this.SubmitText.Visibility = Visibility.Visible;
        this.IsLoading = false;
      }
      else
      {
        this.SubmitButton.IsHitTestVisible = false;
        this.LoadingCircle.Visibility = Visibility.Visible;
        this.SubmitText.Visibility = Visibility.Collapsed;
        this.IsLoading = true;
      }
    }

    private async void RequestEmailVerfication()
    {
      try
      {
        await WaveInterface.RequestEmailVerification(this.UsernameBox.Text);
        this.ToastNotification.Success("An email verification has been sent. Please check your inbox to complete the verification process.");
      }
      catch (Exception ex)
      {
        this.ToastNotification.Error(ex.Message);
      }
    }

    public void ShowUnhandledExceptionError(UnhandledExceptionErrorType type, string message)
    {
      this.UnhandledExceptionError.Show(this.BlurEffect, this.GetUnhandledExceptionErrorTitle(type), message);
    }

    private string GetUnhandledExceptionErrorTitle(UnhandledExceptionErrorType type)
    {
      switch (type)
      {
        case UnhandledExceptionErrorType.ApplicationError:
          return "Application Error";
        case UnhandledExceptionErrorType.SecurityError:
          return "Security Error";
        case UnhandledExceptionErrorType.RegistryError:
          return "Registry Error";
        default:
          throw new ArgumentException("GetUnhandledExceptionErrorTitle.UnhandledExceptionErrorType");
      }
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      Application.LoadComponent((object) this, new Uri("/WaveWindows;component/loginwindow.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    internal Delegate _CreateDelegate(Type delegateType, string handler)
    {
      return Delegate.CreateDelegate(delegateType, (object) this, handler);
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int connectionId, object target)
    {
      switch (connectionId)
      {
        case 1:
          ((FrameworkElement) target).Loaded += new RoutedEventHandler(this.Window_Loaded);
          break;
        case 2:
          this.Background = (Border) target;
          this.Background.MouseDown += new MouseButtonEventHandler(this.Background_MouseDown);
          break;
        case 3:
          this.BlurEffect = (BlurEffect) target;
          break;
        case 4:
          this.FirstNavigationButtonText = (TextBlock) target;
          break;
        case 5:
          this.SecondNavigationButton = (System.Windows.Controls.Button) target;
          this.SecondNavigationButton.Click += new RoutedEventHandler(this.SecondNavigationButton_Click);
          break;
        case 6:
          this.SecondNavigationButtonText = (TextBlock) target;
          break;
        case 7:
          this.SecondNavigationText = (TextBlock) target;
          break;
        case 8:
          this.SecondNavigationTextButton = (TextBlock) target;
          this.SecondNavigationTextButton.MouseDown += new MouseButtonEventHandler(this.SecondNavigationTextButton_MouseDown);
          break;
        case 9:
          this.FirstNavigationText = (TextBlock) target;
          break;
        case 10:
          this.FirstNavigationTextButton = (TextBlock) target;
          this.FirstNavigationTextButton.MouseDown += new MouseButtonEventHandler(this.FirstNavigationTextButton_MouseDown);
          break;
        case 11:
          this.UsernameBox = (InputBox) target;
          break;
        case 12:
          this.EmailBox = (InputBox) target;
          break;
        case 13:
          this.PasswordBox = (SecureTextBox) target;
          break;
        case 14:
          this.RecoverPasswordButton = (TextBlock) target;
          this.RecoverPasswordButton.MouseDown += new MouseButtonEventHandler(this.RecoverPasswordButton_MouseDown);
          break;
        case 15:
          this.SubmitButton = (System.Windows.Controls.Button) target;
          this.SubmitButton.Click += new RoutedEventHandler(this.SubmitButton_Click);
          break;
        case 16:
          this.LoadingCircle = (Border) target;
          break;
        case 17:
          this.SubmitButtonRotateTransform = (RotateTransform) target;
          break;
        case 18:
          this.SubmitText = (TextBlock) target;
          break;
        case 19:
          this.ToastNotification = (WaveWindows.Controls.Toast.Container) target;
          break;
        case 20:
          this.UnhandledExceptionError = (UnhandledExceptionError) target;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }
  }
}
