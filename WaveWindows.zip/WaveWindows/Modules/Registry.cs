﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Modules.Registry
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using Microsoft.Win32;
using System;

#nullable disable
namespace WaveWindows.Modules
{
  internal class Registry
  {
    private static Registry Instance { get; set; }

    private RegistryKey Key { get; set; }

    internal Registry(string Path) => this.Key = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(Path);

    internal static Registry Configuration
    {
      get
      {
        if (Registry.Instance != null)
          return Registry.Instance;
        Registry.Instance = new Registry("Software\\KasperskyLab");
        return Registry.Instance;
      }
    }

    internal object this[string key, object defaultValue = null]
    {
      get => this.Key.GetValue(key, defaultValue);
      set
      {
        RegistryValueKind valueKind = RegistryValueKind.String;
        switch (value)
        {
          case int _:
          case bool _:
            valueKind = RegistryValueKind.DWord;
            break;
        }
        this.Key.SetValue(key, value, valueKind);
      }
    }

    internal bool ContinueOnStartUp
    {
      get => Convert.ToBoolean(this[nameof (ContinueOnStartUp), (object) false]);
      set => this[nameof (ContinueOnStartUp)] = (object) value;
    }

    internal bool TopMost
    {
      get => Convert.ToBoolean(this[nameof (TopMost), (object) false]);
      set => this[nameof (TopMost)] = (object) value;
    }

    internal bool RedirectCompilerError
    {
      get => Convert.ToBoolean(this[nameof (RedirectCompilerError), (object) true]);
      set => this[nameof (RedirectCompilerError)] = (object) value;
    }

    internal bool UsePerformanceMode
    {
      get => Convert.ToBoolean(this[nameof (UsePerformanceMode), (object) false]);
      set => this[nameof (UsePerformanceMode)] = (object) value;
    }

    internal int RefreshRate
    {
      get => Convert.ToInt32(this[nameof (RefreshRate), (object) 60]);
      set => this[nameof (RefreshRate)] = (object) value;
    }

    internal int FontSize
    {
      get => Convert.ToInt32(this[nameof (FontSize), (object) 14]);
      set => this[nameof (FontSize)] = (object) value;
    }

    internal bool Minimap
    {
      get => Convert.ToBoolean(this[nameof (Minimap), (object) false]);
      set => this[nameof (Minimap)] = (object) value;
    }

    internal bool InlayHints
    {
      get => Convert.ToBoolean(this[nameof (InlayHints), (object) true]);
      set => this[nameof (InlayHints)] = (object) value;
    }

    internal bool UseConversationHistory
    {
      get => Convert.ToBoolean(this[nameof (UseConversationHistory), (object) true]);
      set => this[nameof (UseConversationHistory)] = (object) value;
    }

    internal bool SendCurrentDocument
    {
      get => Convert.ToBoolean(this[nameof (SendCurrentDocument), (object) true]);
      set => this[nameof (SendCurrentDocument)] = (object) value;
    }

    internal string Session
    {
      get => Convert.ToString(this[nameof (Session), (object) string.Empty]);
      set => this[nameof (Session)] = (object) value;
    }

    internal string LastUsername
    {
      get => Convert.ToString(this[nameof (LastUsername), (object) string.Empty]);
      set => this[nameof (LastUsername)] = (object) value;
    }

    internal string FirstHash
    {
      get => Convert.ToString(this[nameof (FirstHash), (object) string.Empty]);
      set => this[nameof (FirstHash)] = (object) value;
    }

    internal string SecondHash
    {
      get => Convert.ToString(this[nameof (SecondHash), (object) string.Empty]);
      set => this[nameof (SecondHash)] = (object) value;
    }
  }
}
