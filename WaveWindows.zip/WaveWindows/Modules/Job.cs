﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Modules.Job
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

#nullable disable
namespace WaveWindows.Modules
{
  internal class Job
  {
    internal static IntPtr INVALID_HANDLE_VALUE = (IntPtr) -1;

    [DllImport("ntdll.dll")]
    private static extern int NtCreateJobObject(
      out IntPtr JobHandle,
      uint DesiredAccess,
      IntPtr ObjectAttributes);

    [DllImport("ntdll.dll")]
    private static extern int NtSetInformationJobObject(
      IntPtr JobHandle,
      Job.JobType JobObjectInformationClass,
      IntPtr JobObjectInformation,
      uint JobObjectInformationLength);

    [DllImport("ntdll.dll")]
    private static extern int NtAssignProcessToJobObject(IntPtr JobHandle, IntPtr ProcessHandle);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr OpenProcess(
      int dwDesiredAccess,
      bool bInheritHandle,
      uint dwProcessId);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool CloseHandle(IntPtr hObject);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr CreateIoCompletionPort(
      IntPtr FileHandle,
      IntPtr ExistingCompletionPort,
      UIntPtr CompletionKey,
      uint NumberOfConcurrentThreads);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool GetQueuedCompletionStatus(
      IntPtr CompletionPort,
      out uint lpNumberOfBytes,
      out UIntPtr lpCompletionKey,
      out IntPtr lpOverlapped,
      uint dwMilliseconds);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool TerminateJobObject(IntPtr hJob, uint uExitCode);

    internal static Job.ObjectPtr ObjectToPtr<T>(T obj)
    {
      int cb = Marshal.SizeOf<T>(obj);
      IntPtr ptr = Marshal.AllocHGlobal(cb);
      Marshal.StructureToPtr<T>(obj, ptr, false);
      return new Job.ObjectPtr()
      {
        Ptr = ptr,
        Size = (uint) cb
      };
    }

    internal static IntPtr Suspend(Process process)
    {
      IntPtr num = Job.OpenProcess(2035711, false, (uint) process.Id);
      IntPtr JobHandle = !(num == IntPtr.Zero) ? IntPtr.Zero : throw new Exception("Failed to open process.");
      if (Job.NtCreateJobObject(out JobHandle, 33554432U, IntPtr.Zero) != 0)
      {
        Job.CloseHandle(num);
        throw new Exception("Failed to create job object.");
      }
      Job.ObjectPtr ptr1 = Job.ObjectToPtr<Job.FreezeInformation>(new Job.FreezeInformation()
      {
        FreezeOperation = true,
        Freeze = (byte) 1
      });
      try
      {
        if (Job.NtSetInformationJobObject(JobHandle, Job.JobType.JobObjectFreezeInformation, ptr1.Ptr, ptr1.Size) != 0)
        {
          Job.CloseHandle(JobHandle);
          Job.CloseHandle(num);
          throw new Exception("Failed to freeze job object.");
        }
        IntPtr ioCompletionPort = Job.CreateIoCompletionPort(new IntPtr(-1), IntPtr.Zero, UIntPtr.Zero, 1U);
        if (ioCompletionPort == IntPtr.Zero)
        {
          Job.CloseHandle(JobHandle);
          Job.CloseHandle(num);
          throw new Exception("Failed to create completion port.");
        }
        Job.ObjectPtr ptr2 = Job.ObjectToPtr<Job.AssociateCompletionPort>(new Job.AssociateCompletionPort()
        {
          CompletionKey = IntPtr.Zero,
          CompletionPort = ioCompletionPort
        });
        try
        {
          if (Job.NtSetInformationJobObject(JobHandle, Job.JobType.JobObjectAssociateCompletionPortInformation, ptr2.Ptr, ptr2.Size) != 0)
          {
            Job.CloseHandle(ioCompletionPort);
            Job.CloseHandle(JobHandle);
            Job.CloseHandle(num);
            throw new Exception("Failed to associate completion port.");
          }
          if (Job.NtAssignProcessToJobObject(JobHandle, num) != 0)
          {
            Job.CloseHandle(ioCompletionPort);
            Job.CloseHandle(JobHandle);
            Job.CloseHandle(num);
            throw new Exception("Failed to assign process to job object.");
          }
          Job.CloseHandle(num);
        }
        finally
        {
          Marshal.FreeHGlobal(ptr2.Ptr);
        }
      }
      finally
      {
        Marshal.FreeHGlobal(ptr1.Ptr);
      }
      return JobHandle;
    }

    internal static bool Resume(IntPtr handle)
    {
      Job.ObjectPtr ptr = Job.ObjectToPtr<Job.FreezeInformation>(new Job.FreezeInformation()
      {
        FreezeOperation = true,
        Freeze = (byte) 0
      });
      try
      {
        if (Job.NtSetInformationJobObject(handle, Job.JobType.JobObjectFreezeInformation, ptr.Ptr, ptr.Size) == 0)
          return true;
        Job.Terminate(handle);
        return false;
      }
      finally
      {
        Marshal.FreeHGlobal(ptr.Ptr);
      }
    }

    internal static bool Terminate(IntPtr handle)
    {
      if (handle == IntPtr.Zero || handle == new IntPtr(-1) || !Job.TerminateJobObject(handle, 0U))
        return false;
      Job.CloseHandle(handle);
      return true;
    }

    internal enum JobType
    {
      Unknown,
      JobObjectBasicAccountingInformation,
      JobObjectBasicLimitInformation,
      JobObjectBasicProcessIdList,
      JobObjectBasicUIRestrictions,
      JobObjectSecurityLimitInformation,
      JobObjectEndOfJobTimeInformation,
      JobObjectAssociateCompletionPortInformation,
      JobObjectBasicAndIoAccountingInformation,
      JobObjectExtendedLimitInformation,
      JobObjectJobSetInformation,
      JobObjectGroupInformation,
      JobObjectNotificationLimitInformation,
      JobObjectLimitViolationInformation,
      JobObjectGroupInformationEx,
      JobObjectCpuRateControlInformation,
      JobObjectCompletionFilter,
      JobObjectCompletionCounter,
      JobObjectFreezeInformation,
      JobObjectExtendedAccountingInformation,
      JobObjectWakeInformation,
      JobObjectBackgroundInformation,
      JobObjectSchedulingRankBiasInformation,
      JobObjectTimerVirtualizationInformation,
      JobObjectCycleTimeNotification,
      JobObjectClearEvent,
      JobObjectInterferenceInformation,
      JobObjectClearPeakJobMemoryUsed,
      JobObjectMemoryUsageInformation,
      JobObjectSharedCommit,
      JobObjectContainerId,
      JobObjectIoRateControlInformation,
      JobObjectNetRateControlInformation,
      JobObjectNotificationLimitInformation2,
      JobObjectLimitViolationInformation2,
      JobObjectCreateSilo,
      JobObjectSiloBasicInformation,
      JobObjectReserved15Information,
      JobObjectReserved16Information,
      JobObjectReserved17Information,
      JobObjectReserved18Information,
      JobObjectReserved19Information,
      JobObjectReserved20Information,
      JobObjectReserved21Information,
      JobObjectReserved22Information,
      JobObjectReserved23Information,
      JobObjectReserved24Information,
      JobObjectReserved25Information,
      JobObjectReserved26Information,
      JobObjectReserved27Information,
      MaxJobObjectInfoClass,
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    internal struct WakeFilter
    {
      internal uint HighEdgeFilter;
      internal uint LowEdgeFilter;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    internal struct FreezeInformation
    {
      private uint Flags;
      internal byte Freeze;
      internal byte Swap;
      private ushort Reserved0;
      internal Job.WakeFilter WakeFilter;

      internal bool FreezeOperation
      {
        get => (this.Flags & 1U) > 0U;
        set => this.Flags = value ? this.Flags | 1U : this.Flags & 4294967294U;
      }

      internal bool FilterOperation
      {
        get => (this.Flags & 2U) > 0U;
        set => this.Flags = value ? this.Flags | 2U : this.Flags & 4294967293U;
      }

      internal bool SwapOperation
      {
        get => (this.Flags & 4U) > 0U;
        set => this.Flags = value ? this.Flags | 4U : this.Flags & 4294967291U;
      }
    }

    internal struct AssociateCompletionPort
    {
      internal IntPtr CompletionKey;
      internal IntPtr CompletionPort;
    }

    internal class ObjectPtr
    {
      internal IntPtr Ptr { get; set; }

      internal uint Size { get; set; }
    }
  }
}
