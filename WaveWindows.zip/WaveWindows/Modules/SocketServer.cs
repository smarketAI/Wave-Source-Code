﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Modules.SocketServer
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Collections.Generic;
using System.Windows;
using WebSocketSharp.Server;

#nullable disable
namespace WaveWindows.Modules
{
  internal class SocketServer : IDisposable
  {
    public WebSocketServer Server { get; set; }

    private List<string> Services { get; set; }

    private static EventHandler<SocketEmittedEventArgs> Emitter { get; set; }

    internal SocketServer(string uri)
    {
      this.Server = new WebSocketServer(uri);
      this.Services = new List<string>();
    }

    internal void Start() => this.Server.Start();

    internal void Listen(
      string path,
      Action<Types.ClientBehaviour.ClientEmittedEventArgs> handler)
    {
      SocketServer.Emitter += (EventHandler<SocketEmittedEventArgs>) ((sender, e) =>
      {
        if (e.Service != path)
          return;
        Application.Current.Dispatcher.Invoke((Action) (() => handler(e.Data)));
      });
    }

    internal static void Emit(string path, Types.ClientBehaviour.ClientEmittedEventArgs data)
    {
      EventHandler<SocketEmittedEventArgs> emitter = SocketServer.Emitter;
      if (emitter == null)
        return;
      emitter((object) null, new SocketEmittedEventArgs()
      {
        Service = path,
        Data = data
      });
    }

    internal void AddService<T>(string path, Func<T> initializer = null) where T : WebSocketBehavior, new()
    {
      if (this.Services.Contains(path))
        return;
      if (initializer != null)
        this.Server.AddWebSocketService<T>(path, initializer);
      else
        this.Server.AddWebSocketService<T>(path);
      this.Services.Add(path);
    }

    internal void RemoveService(string path)
    {
      if (!this.Services.Contains(path))
        return;
      this.Server.RemoveWebSocketService(path);
      this.Services.Remove(path);
    }

    public void Dispose()
    {
      foreach (string service in this.Services)
        this.RemoveService(service);
      this.Server.Stop();
    }
  }
}
