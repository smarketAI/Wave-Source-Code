﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Modules.Cryptography
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

#nullable disable
namespace WaveWindows.Modules
{
  internal static class Cryptography
  {
    internal static class SHA1
    {
      internal static string Compute(string input)
      {
        using (SHA1Managed shA1Managed = new SHA1Managed())
        {
          byte[] bytes = Encoding.UTF8.GetBytes(input);
          return BitConverter.ToString(shA1Managed.ComputeHash(bytes)).Replace("-", string.Empty);
        }
      }
    }

    internal static class SHA256
    {
      internal static string GetHashFromFile(string filePath)
      {
        using (FileStream inputStream = File.OpenRead(filePath))
        {
          using (System.Security.Cryptography.SHA256 shA256 = System.Security.Cryptography.SHA256.Create())
          {
            StringBuilder stringBuilder = new StringBuilder(64);
            foreach (byte num in shA256.ComputeHash((Stream) inputStream))
              stringBuilder.Append(num.ToString("x2"));
            return stringBuilder.ToString().ToUpper();
          }
        }
      }
    }

    internal static class MD5
    {
      internal static string GetHashFromFile(string filePath)
      {
        using (FileStream inputStream = File.OpenRead(filePath))
        {
          using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
          {
            StringBuilder stringBuilder = new StringBuilder(32);
            foreach (byte num in md5.ComputeHash((Stream) inputStream))
              stringBuilder.Append(num.ToString("x2"));
            return stringBuilder.ToString().ToUpper();
          }
        }
      }
    }
  }
}
