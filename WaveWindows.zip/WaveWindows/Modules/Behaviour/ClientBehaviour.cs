﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Modules.Behaviour.ClientBehaviour
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebSocketSharp;
using WebSocketSharp.Server;

#nullable disable
namespace WaveWindows.Modules.Behaviour
{
  internal class ClientBehaviour : WebSocketBehavior
  {
    private static Dictionary<string, WebSocket> Clients = new Dictionary<string, WebSocket>();
    private static JsonSerializerSettings JsonSerializerSettings = new JsonSerializerSettings()
    {
      NullValueHandling = (NullValueHandling) 1,
      MissingMemberHandling = (MissingMemberHandling) 0
    };
    private static Dictionary<string, List<object>> WaitForCodes = new Dictionary<string, List<object>>();

    internal string Service { get; set; }

    private void Emit(string OpCode, object Data)
    {
      if (string.IsNullOrEmpty(this.Service))
        throw new NullReferenceException("Service is not set");
      SocketServer.Emit(this.Service, new Types.ClientBehaviour.ClientEmittedEventArgs(OpCode, Data));
    }

    private void TryAddToCode<T>(string code, T data)
    {
      if (!ClientBehaviour.WaitForCodes.ContainsKey(code))
        return;
      ClientBehaviour.WaitForCodes[code].Add((object) data);
    }

    protected virtual void OnMessage(MessageEventArgs e)
    {
      base.OnMessage(e);
      Types.ClientBehaviour.ClientMessage clientMessage = JsonConvert.DeserializeObject<Types.ClientBehaviour.ClientMessage>(e.Data, ClientBehaviour.JsonSerializerSettings);
      string str = clientMessage.Data.ToString();
      switch (clientMessage.OpCode)
      {
        case "OP_IDENTIFY":
          Types.ClientBehaviour.ClientIdentity clientIdentity = JsonConvert.DeserializeObject<Types.ClientBehaviour.ClientIdentity>(str, ClientBehaviour.JsonSerializerSettings);
          if (ClientBehaviour.Clients.FirstOrDefault<KeyValuePair<string, WebSocket>>((Func<KeyValuePair<string, WebSocket>, bool>) (x => x.Value == this.Context.WebSocket)).Value != null)
          {
            this.Emit("OP_UPDATE", (object) clientIdentity);
            break;
          }
          this.TryAddToCode<Types.ClientBehaviour.ClientIdentity>("OP_IDENTIFY", clientIdentity);
          ClientBehaviour.Clients.Add(clientIdentity.Process.Id, this.Context.WebSocket);
          this.Emit("OP_IDENTIFY", (object) clientIdentity);
          break;
        case "OP_HEARTBEAT":
          KeyValuePair<string, WebSocket> keyValuePair = ClientBehaviour.Clients.FirstOrDefault<KeyValuePair<string, WebSocket>>((Func<KeyValuePair<string, WebSocket>, bool>) (x => x.Value == this.Context.WebSocket));
          if (keyValuePair.Value == null)
          {
            this.Context.WebSocket.CloseAsync();
            break;
          }
          keyValuePair.Value.Send(JsonConvert.SerializeObject((object) new Types.ClientBehaviour.ClientMessage()
          {
            OpCode = "OP_HEARTBEAT_ACK",
            Data = (object) new{  }
          }));
          break;
        case "OP_SCRIPT":
          break;
        default:
          if (ClientBehaviour.Clients.FirstOrDefault<KeyValuePair<string, WebSocket>>((Func<KeyValuePair<string, WebSocket>, bool>) (x => x.Value == this.Context.WebSocket)).Value == null)
          {
            this.Context.WebSocket.CloseAsync();
            break;
          }
          this.Emit(clientMessage.OpCode, (object) JsonConvert.DeserializeObject<Types.ClientBehaviour.ClientError>(str));
          break;
      }
    }

    protected virtual void OnClose(CloseEventArgs e)
    {
      base.OnClose(e);
      KeyValuePair<string, WebSocket> keyValuePair = ClientBehaviour.Clients.FirstOrDefault<KeyValuePair<string, WebSocket>>((Func<KeyValuePair<string, WebSocket>, bool>) (x => x.Value == this.Context.WebSocket));
      if (keyValuePair.Value == null)
        return;
      ClientBehaviour.Clients.Remove(keyValuePair.Key);
      this.Emit("OP_DISCONNECT", (object) keyValuePair.Key);
    }

    public static string[] GetAllClients() => ClientBehaviour.Clients.Keys.ToArray<string>();

    public static WebSocket GetClient(string name) => ClientBehaviour.Clients[name];

    public static async Task<List<T>> WaitFor<T>(string code, int seconds)
    {
      if (!ClientBehaviour.WaitForCodes.ContainsKey(code))
        ClientBehaviour.WaitForCodes.Add(code, new List<object>());
      await Task.Delay(seconds * 1000);
      List<T> list = ClientBehaviour.WaitForCodes[code].Cast<T>().ToList<T>();
      ClientBehaviour.WaitForCodes.Remove(code);
      return list;
    }

    public static async Task ExecuteScriptAsync(string name, int id, string data)
    {
      WebSocket client = ClientBehaviour.GetClient(name);
      if (client == null || !client.IsAlive || client.ReadyState != 1)
        return;
      string json = JsonConvert.SerializeObject((object) new Types.ClientBehaviour.ClientMessage()
      {
        OpCode = "OP_EXECUTE",
        Data = (object) new{ id = id, source = data }
      });
      await Task.Run((Action) (() => client.Send(json)));
    }
  }
}
