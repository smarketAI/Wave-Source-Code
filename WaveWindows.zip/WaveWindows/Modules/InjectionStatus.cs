﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Modules.InjectionStatus
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

#nullable disable
namespace WaveWindows.Modules
{
  internal enum InjectionStatus
  {
    Waiting,
    Injecting,
    Failed,
    Downloading,
    Injected,
    Outdated,
  }
}
