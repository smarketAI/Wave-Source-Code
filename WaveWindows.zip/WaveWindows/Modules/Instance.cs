﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Modules.Instance
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using WaveWindows.Interfaces;

#nullable disable
namespace WaveWindows.Modules
{
  internal class Instance
  {
    internal Process Process { get; private set; }

    internal IntPtr Job { get; private set; }

    internal Instance(Process process)
    {
      this.Process = process;
      this.Job = IntPtr.Zero;
    }

    internal async Task IsReady()
    {
      while (this.Process.MainWindowHandle == IntPtr.Zero)
        await Task.Delay(100);
    }

    internal void Suspend() => this.Job = WaveWindows.Modules.Job.Suspend(this.Process);

    internal void Resume()
    {
      if (this.Job == IntPtr.Zero || this.Job == new IntPtr(-1))
        return;
      WaveWindows.Modules.Job.Resume(this.Job);
    }

    internal void Inject(Action<InjectionStatus, object> callback, int delay = 0)
    {
      new Thread((ThreadStart) (async () =>
      {
        callback(InjectionStatus.Waiting, (object) null);
        await this.IsReady();
        callback(InjectionStatus.Injecting, (object) null);
        this.Suspend();
        using (Process injector = InjectorInterface.GetInjector(this.Process.Id))
        {
          try
          {
            injector.Start();
            injector.WaitForExit();
            if (injector.ExitCode == 0)
              return;
            callback(InjectionStatus.Failed, (object) ("0x" + injector.ExitCode.ToString("X")));
            this.Process.Kill();
          }
          catch (Exception ex)
          {
            callback(InjectionStatus.Failed, (object) ex.Message);
          }
          finally
          {
            this.Resume();
          }
        }
      })).Start();
    }

    internal void Terminate() => WaveWindows.Modules.Job.Terminate(this.Job);
  }
}
