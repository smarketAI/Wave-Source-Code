﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Modules.WmiProcessWatcher
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Management;
using System.Windows;

#nullable disable
namespace WaveWindows.Modules
{
  internal class WmiProcessWatcher
  {
    private ManagementEventWatcher StartWatcher { get; set; }

    private string ProcessName { get; set; }

    private Dictionary<int, Instance> Processes { get; set; }

    internal WmiProcessWatcher(string processName)
    {
      this.StartWatcher = new ManagementEventWatcher((EventQuery) new WqlEventQuery("SELECT * FROM Win32_ProcessStartTrace"));
      this.ProcessName = processName;
      this.Processes = new Dictionary<int, Instance>();
    }

    internal void Once(Action<List<Instance>> callback)
    {
      List<Instance> instances = new List<Instance>();
      foreach (Process process in Process.GetProcessesByName(this.ProcessName))
        instances.Add(new Instance(process));
      Application.Current.Dispatcher.Invoke((Action) (() => callback(instances)));
    }

    internal void Start(Action<Instance, ProcessState> callback)
    {
      this.StartWatcher.EventArrived += (EventArrivedEventHandler) ((s, e) =>
      {
        string str = e.NewEvent.Properties["ProcessName"].Value.ToString();
        int int32 = Convert.ToInt32(e.NewEvent.Properties["ProcessId"].Value);
        string processName = this.ProcessName;
        if (!str.StartsWith(processName) || this.Processes.ContainsKey(int32))
          return;
        Instance instance = new Instance(Process.GetProcessById(int32));
        this.Processes.Add(int32, instance);
        Application.Current.Dispatcher.Invoke((Action) (() => callback(instance, ProcessState.Running)));
      });
      this.StartWatcher.Start();
    }

    internal void Stop() => this.StartWatcher.Stop();
  }
}
