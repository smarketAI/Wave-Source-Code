﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Modules.Hardware
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using Microsoft.Win32;
using System;

#nullable disable
namespace WaveWindows.Modules
{
  internal class Hardware
  {
    private static RegistryKey RegistryKey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\IDConfigDB\\Hardware Profiles\\0001", true);

    private static Hardware Instance { get; set; }

    internal Hardware()
    {
      if (Hardware.RegistryKey == null)
        throw new NullReferenceException("Hardware Profile not found.");
    }

    internal static Hardware CurrentProfile
    {
      get
      {
        if (Hardware.Instance != null)
          return Hardware.Instance;
        Hardware.Instance = new Hardware();
        return Hardware.Instance;
      }
    }

    internal string this[string key]
    {
      get => Hardware.RegistryKey.GetValue(key).ToString();
      set => Hardware.RegistryKey.SetValue(key, (object) value);
    }

    internal string Guid
    {
      get => this["HwProfileGuid"].ToUpper();
      set => this["HwProfileGuid"] = value;
    }
  }
}
