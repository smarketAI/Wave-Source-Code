﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Properties.Resources
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace WaveWindows.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (WaveWindows.Properties.Resources.resourceMan == null)
          WaveWindows.Properties.Resources.resourceMan = new ResourceManager("WaveWindows.Properties.Resources", typeof (WaveWindows.Properties.Resources).Assembly);
        return WaveWindows.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => WaveWindows.Properties.Resources.resourceCulture;
      set => WaveWindows.Properties.Resources.resourceCulture = value;
    }
  }
}
