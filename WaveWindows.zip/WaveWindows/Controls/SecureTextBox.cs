﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.SecureTextBox
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;

#nullable disable
namespace WaveWindows.Controls
{
  internal class SecureTextBox : TextBox
  {
    internal static readonly DependencyProperty PasswordProperty;
    internal static readonly DependencyProperty ShowProperty;
    internal static readonly DependencyProperty PlaceholderProperty;
    private readonly DispatcherTimer Interval = new DispatcherTimer()
    {
      Interval = new TimeSpan(0, 0, 0, 1)
    };

    internal string Password
    {
      get => (string) this.GetValue(SecureTextBox.PasswordProperty);
      set => this.SetValue(SecureTextBox.PasswordProperty, (object) value);
    }

    internal bool Show
    {
      get => (bool) this.GetValue(SecureTextBox.ShowProperty);
      private set => this.SetValue(SecureTextBox.ShowProperty, (object) value);
    }

    internal string Placeholder
    {
      get => (string) this.GetValue(SecureTextBox.PlaceholderProperty);
      set => this.SetValue(SecureTextBox.PlaceholderProperty, (object) value);
    }

    static SecureTextBox()
    {
      FrameworkElement.DefaultStyleKeyProperty.OverrideMetadata(typeof (SecureTextBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) typeof (SecureTextBox)));
      SecureTextBox.PasswordProperty = DependencyProperty.Register(nameof (Password), typeof (string), typeof (SecureTextBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
      SecureTextBox.ShowProperty = DependencyProperty.Register(nameof (Show), typeof (bool), typeof (SecureTextBox), (PropertyMetadata) new UIPropertyMetadata((object) false, new PropertyChangedCallback(SecureTextBox.OnShowPropertyChanged)));
      SecureTextBox.PlaceholderProperty = DependencyProperty.Register(nameof (Placeholder), typeof (string), typeof (SecureTextBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    }

    private void OnPreviewExecuted(object sender, ExecutedRoutedEventArgs e)
    {
      if (e.Command == ApplicationCommands.Copy)
        e.Handled = true;
      if (e.Command != ApplicationCommands.Paste)
        return;
      if (Clipboard.ContainsText())
        this.StoreString(Clipboard.GetText());
      e.Handled = true;
    }

    private void OnPreviewTextInput(object sender, TextCompositionEventArgs e)
    {
      this.StoreString(e.Text);
      e.Handled = true;
    }

    private void OnPreviewKeyDown(object sender, KeyEventArgs e)
    {
      Key key = e.Key == Key.System ? e.SystemKey : e.Key;
      switch (key)
      {
        case Key.Back:
        case Key.Delete:
          if (this.SelectionLength > 0)
            this.DiscardString(this.SelectionStart, this.SelectionLength);
          else if (key == Key.Delete && this.CaretIndex < this.Text.Length)
            this.DiscardString(this.CaretIndex, 1);
          else if (key == Key.Back && this.CaretIndex > 0)
          {
            int caretIndex = this.CaretIndex;
            if (this.CaretIndex > 0 && this.CaretIndex < this.Text.Length)
              --caretIndex;
            this.DiscardString(this.CaretIndex - 1, 1);
            this.CaretIndex = caretIndex;
          }
          e.Handled = true;
          break;
        case Key.Tab:
        case Key.Return:
          e.Handled = true;
          break;
        case Key.Space:
          this.StoreString(" ");
          e.Handled = true;
          break;
      }
    }

    private void StoreString(string Value)
    {
      if (this.SelectionLength > 0)
        this.DiscardString(this.SelectionStart, this.SelectionLength);
      foreach (char ch in Value)
      {
        int caretIndex = this.CaretIndex;
        string str1 = ch.ToString();
        this.Password = this.Password.Insert(caretIndex, str1);
        this.ToggleDisplay();
        int num;
        if (caretIndex == this.Text.Length)
        {
          this.Interval.Stop();
          this.Interval.Start();
          string text = this.Text;
          int startIndex = caretIndex;
          num = startIndex + 1;
          string str2 = str1;
          this.Text = text.Insert(startIndex, str2);
        }
        else if (this.Show)
        {
          string text = this.Text;
          int startIndex = caretIndex;
          num = startIndex + 1;
          string str3 = str1;
          this.Text = text.Insert(startIndex, str3);
        }
        else
        {
          string text = this.Text;
          int startIndex = caretIndex;
          num = startIndex + 1;
          this.Text = text.Insert(startIndex, "●");
        }
        this.CaretIndex = num;
      }
    }

    private void DiscardString(int Start, int Length)
    {
      int caretIndex = this.CaretIndex;
      this.Password = this.Password.Remove(Start, Length);
      this.Text = this.Text.Remove(Start, Length);
      this.CaretIndex = caretIndex;
    }

    private void ToggleDisplay()
    {
      if (this.Show)
        return;
      this.Interval.Stop();
      int caretIndex = this.CaretIndex;
      this.Text = new string('●', this.Text.Length);
      this.CaretIndex = caretIndex;
    }

    private static void OnShowPropertyChanged(
      DependencyObject sender,
      DependencyPropertyChangedEventArgs e)
    {
      if (!(sender is SecureTextBox secureTextBox))
        return;
      secureTextBox.Show = (bool) e.NewValue;
    }

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      this.Interval.Tick += (EventHandler) ((sender, args) => this.ToggleDisplay());
      this.PreviewKeyDown += new KeyEventHandler(this.OnPreviewKeyDown);
      this.PreviewTextInput += new TextCompositionEventHandler(this.OnPreviewTextInput);
      CommandManager.AddPreviewExecutedHandler((UIElement) this, new ExecutedRoutedEventHandler(this.OnPreviewExecuted));
      if (!(this.GetTemplateChild("ShowButton") is Image templateChild))
        return;
      templateChild.PreviewMouseDown += (MouseButtonEventHandler) ((sender, e) =>
      {
        string password = this.Password;
        int caretIndex = this.CaretIndex;
        if (!this.Show)
        {
          this.Show = true;
          this.Text = "";
          this.Text = password;
          this.CaretIndex = caretIndex;
        }
        else
        {
          this.Show = false;
          this.ToggleDisplay();
        }
      });
    }
  }
}
