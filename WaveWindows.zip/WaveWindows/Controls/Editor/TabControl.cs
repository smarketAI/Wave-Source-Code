﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.Editor.TabControl
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WaveWindows.Interfaces;

#nullable disable
namespace WaveWindows.Controls.Editor
{
  internal class TabControl : System.Windows.Controls.TabControl
  {
    private Monaco _CurrentEditor;
    private ScrollViewer ScrollViewer;
    private EditorInterface.EditorOptions EditorOptions;

    internal Monaco CurrentEditor
    {
      get => this._CurrentEditor;
      set => this._CurrentEditor = value;
    }

    internal void SetEditorOptions(EditorInterface.EditorOptions Options)
    {
      this.EditorOptions = Options;
    }

    internal TabItem AddTab(string Header, string Content)
    {
      TabItem tabItem1 = new TabItem();
      tabItem1.Id = new Random().Next();
      tabItem1.Header = (object) Header;
      tabItem1.Content = (object) new Monaco("http://localhost:6969", Content, this.EditorOptions);
      TabItem tabItem2 = tabItem1;
      this.AddChild((object) tabItem2);
      this.SelectedItem = (object) tabItem2;
      this.CurrentEditor = tabItem2.Content as Monaco;
      if (this.ScrollViewer != null)
        this.ScrollViewer.ScrollToRightEnd();
      return tabItem2;
    }

    internal Monaco SelectById(int Id)
    {
      foreach (TabItem allTab in this.GetAllTabs())
      {
        if (allTab.Id == Id)
        {
          this.SelectedItem = (object) allTab;
          this.CurrentEditor = allTab.Content as Monaco;
          return this.CurrentEditor;
        }
      }
      return (Monaco) null;
    }

    internal TabItem[] GetAllTabs()
    {
      TabItem[] allTabs = new TabItem[this.Items.Count];
      for (int index = 0; index < this.Items.Count; ++index)
        allTabs[index] = this.Items.GetItemAt(index) as TabItem;
      return allTabs;
    }

    internal Monaco[] GetAllEditors()
    {
      Monaco[] allEditors = new Monaco[this.Items.Count];
      for (int index = 0; index < this.Items.Count; ++index)
        allEditors[index] = (this.Items.GetItemAt(index) as TabItem).Content as Monaco;
      return allEditors;
    }

    internal static Monaco GetSelectedOrLastEditor(TabControl tabControl)
    {
      return ((tabControl.SelectedItem != null ? tabControl.SelectedItem : tabControl.Items.GetItemAt(tabControl.Items.Count - 1)) as TabItem).Content as Monaco;
    }

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      this.SelectionChanged += (SelectionChangedEventHandler) ((sender, e) =>
      {
        if (!(e.Source is TabControl source2))
          return;
        this.CurrentEditor = TabControl.GetSelectedOrLastEditor(source2);
      });
      ScrollViewer ScrollViewer = this.GetTemplateChild("ScrollViewer") as ScrollViewer;
      WaveWindows.Controls.Button templateChild = this.GetTemplateChild("AddTabButton") as WaveWindows.Controls.Button;
      if (ScrollViewer == null)
        throw new ArgumentNullException("ScrollViewer");
      if (templateChild == null)
        throw new ArgumentNullException("AddTabButton");
      this.ScrollViewer = ScrollViewer;
      ScrollViewer.PreviewMouseWheel += (MouseWheelEventHandler) ((sender, e) =>
      {
        if (e.Delta > 0)
          ScrollViewer.ScrollToHorizontalOffset(ScrollViewer.HorizontalOffset - 15.0);
        else if (e.Delta < 0)
          ScrollViewer.ScrollToHorizontalOffset(ScrollViewer.HorizontalOffset + 15.0);
        e.Handled = true;
      });
      templateChild.Click += (RoutedEventHandler) ((sender, e) => this.AddTab("Untitled Tab", "print(\"Hello World!\")"));
    }
  }
}
