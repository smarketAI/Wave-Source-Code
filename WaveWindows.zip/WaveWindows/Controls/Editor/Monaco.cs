﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.Editor.Monaco
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using CefSharp;
using CefSharp.Wpf;
using System;
using System.Threading.Tasks;
using WaveWindows.Interfaces;

#nullable disable
namespace WaveWindows.Controls.Editor
{
  internal class Monaco : ChromiumWebBrowser
  {
    internal System.Threading.Tasks.TaskCompletionSource<bool> TaskCompletionSource = new System.Threading.Tasks.TaskCompletionSource<bool>();

    internal Monaco(string Address, string Text, EditorInterface.EditorOptions editorOptions)
    {
      Monaco monaco = this;
      this.Address = Address;
      this.BrowserSettings = (IBrowserSettings) new CefSharp.BrowserSettings()
      {
        WindowlessFrameRate = 60
      };
      this.LoadingStateChanged += (EventHandler<LoadingStateChangedEventArgs>) (async (sender, e) =>
      {
        if (e.IsLoading)
          return;
        await Task.Delay(1500);
        monaco.TaskCompletionSource.SetResult(true);
        monaco.SetText(Text);
        if (editorOptions == null)
          return;
        monaco.UpdateOptions(editorOptions);
      });
    }

    internal async void SetBrowserFramerate(int framerate)
    {
      Monaco browser = this;
      int num = await browser.TaskCompletionSource.Task ? 1 : 0;
      browser.GetBrowserHost().WindowlessFrameRate = framerate;
    }

    internal Task<T> EvaluateScriptAsync<T>(string method)
    {
      Task<JavascriptResponse> scriptAsync = this.EvaluateScriptAsync(method + "();", new TimeSpan?(), false);
      scriptAsync.Wait();
      JavascriptResponse result = scriptAsync.Result;
      return Task.FromResult<T>((T) (result.Success ? result.Result ?? (object) default (T) : (object) result.Message));
    }

    internal async Task<string> GetText()
    {
      return await this.EvaluateScriptAsync<string>("window.getText");
    }

    internal void SetText(string text) => this.EvaluateScriptAsync("window.setText", (object) text);

    internal void GoToLine(int line) => this.EvaluateScriptAsync("window.goToLine", (object) line);

    internal void SetTheme(string theme, bool _default = false)
    {
      this.EvaluateScriptAsync("window.setTheme", (object) theme, (object) _default);
    }

    internal void SetFontSize(int fontSize)
    {
      this.UpdateOptions(new EditorInterface.EditorOptions()
      {
        FontSize = fontSize
      });
    }

    internal void SetMinimap(bool enabled)
    {
      this.UpdateOptions(new EditorInterface.EditorOptions()
      {
        Minimap = new EditorInterface.MinimapOptions()
        {
          Enabled = enabled
        }
      });
    }

    internal void SetInlayHints(bool enabled)
    {
      this.UpdateOptions(new EditorInterface.EditorOptions()
      {
        InlayHints = new EditorInterface.InlayHintsOptions()
        {
          Enabled = enabled
        }
      });
    }

    internal async void UpdateOptions(EditorInterface.EditorOptions editorOptions)
    {
      Monaco browser = this;
      int num = await browser.TaskCompletionSource.Task ? 1 : 0;
      browser.ExecuteScriptAsync(string.Format("window.updateOptions({0})", (object) editorOptions));
    }
  }
}
