﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.Editor.TabItem
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Windows;

#nullable disable
namespace WaveWindows.Controls.Editor
{
  internal class TabItem : System.Windows.Controls.TabItem
  {
    internal int Id { get; set; }

    internal Monaco GetEditor()
    {
      return this.Content is Monaco content ? content : throw new ArgumentNullException("Editor");
    }

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      if (!(this.GetTemplateChild("RemoveTabButton") is WaveWindows.Controls.Button templateChild))
        throw new ArgumentNullException("RemoveTabButton");
      templateChild.Click += (RoutedEventHandler) ((sender, e) =>
      {
        if (!(this.Parent is TabControl parent2))
          throw new ArgumentNullException("Parent");
        if (parent2.Items.Count < 2)
          return;
        parent2.Items.Remove((object) this);
      });
    }
  }
}
