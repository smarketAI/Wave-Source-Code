﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.Card.Client
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

#nullable disable
namespace WaveWindows.Controls.Card
{
  internal class Client : UserControl
  {
    internal static readonly DependencyProperty PlayerProperty = DependencyProperty.Register(nameof (Player), typeof (string), typeof (Client), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty GameProperty = DependencyProperty.Register(nameof (Game), typeof (string), typeof (Client), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty ImageProperty = DependencyProperty.Register(nameof (Image), typeof (ImageSource), typeof (Client), (PropertyMetadata) new FrameworkPropertyMetadata((PropertyChangedCallback) null));
    internal static readonly DependencyProperty IsCheckedProperty = DependencyProperty.Register(nameof (IsChecked), typeof (bool), typeof (Client), (PropertyMetadata) new FrameworkPropertyMetadata((object) false));
    internal EventHandler<string> Checked;

    internal string Id { get; set; }

    internal string Player
    {
      get => (string) this.GetValue(Client.PlayerProperty);
      set => this.SetValue(Client.PlayerProperty, (object) value);
    }

    internal string Game
    {
      get => (string) this.GetValue(Client.GameProperty);
      set => this.SetValue(Client.GameProperty, (object) value);
    }

    internal ImageSource Image
    {
      get => (ImageSource) this.GetValue(Client.ImageProperty);
      set => this.SetValue(Client.ImageProperty, (object) value);
    }

    internal bool IsChecked
    {
      get => (bool) this.GetValue(Client.IsCheckedProperty);
      set
      {
        this.SetValue(Client.IsCheckedProperty, (object) value);
        EventHandler<string> eventHandler = this.Checked;
        if (eventHandler == null)
          return;
        eventHandler((object) this, this.Player);
      }
    }

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      this.MouseDown += (MouseButtonEventHandler) ((sender, e) => this.IsChecked = !this.IsChecked);
    }
  }
}
