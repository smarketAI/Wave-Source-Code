﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.Card.Script
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

#nullable disable
namespace WaveWindows.Controls.Card
{
  internal class Script : UserControl
  {
    internal static readonly DependencyProperty TitleProperty = DependencyProperty.Register(nameof (Title), typeof (string), typeof (Script), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty DescriptionProperty = DependencyProperty.Register(nameof (Description), typeof (string), typeof (Script), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty FooterProperty = DependencyProperty.Register(nameof (Footer), typeof (string), typeof (Script), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty ImageProperty = DependencyProperty.Register("Image", typeof (ImageSource), typeof (Script), (PropertyMetadata) new FrameworkPropertyMetadata((PropertyChangedCallback) null));

    internal string Title
    {
      get => (string) this.GetValue(Script.TitleProperty);
      set => this.SetValue(Script.TitleProperty, (object) value);
    }

    internal string Description
    {
      get => (string) this.GetValue(Script.DescriptionProperty);
      set => this.SetValue(Script.DescriptionProperty, (object) value);
    }

    internal string Footer
    {
      get => (string) this.GetValue(Script.FooterProperty);
      set => this.SetValue(Script.FooterProperty, (object) value);
    }

    internal ImageSource ImageSource
    {
      get => (ImageSource) this.GetValue(Script.ImageProperty);
      set => this.SetValue(Script.ImageProperty, (object) value);
    }

    public override void OnApplyTemplate() => base.OnApplyTemplate();
  }
}
