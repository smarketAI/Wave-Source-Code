﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.InputBox
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

#nullable disable
namespace WaveWindows.Controls
{
  internal class InputBox : TextBox
  {
    internal static readonly DependencyProperty PlaceholderProperty = DependencyProperty.Register(nameof (Placeholder), typeof (string), typeof (InputBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty PlaceholderStyleProperty = DependencyProperty.Register(nameof (PlaceholderStyle), typeof (FontStyle), typeof (InputBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) FontStyles.Normal));
    internal static readonly DependencyProperty PlaceholderForegroundProperty = DependencyProperty.Register(nameof (PlaceholderForeground), typeof (Brush), typeof (InputBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) new SolidColorBrush((Color) ColorConverter.ConvertFromString("#FFFFFF"))));
    internal static readonly DependencyProperty CornerRadiusProperty = DependencyProperty.Register(nameof (CornerRadius), typeof (CornerRadius), typeof (InputBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) new CornerRadius(7.5)));
    internal static readonly DependencyProperty ClearButtonVisibilityProperty = DependencyProperty.Register(nameof (ClearButtonVisibility), typeof (Visibility), typeof (InputBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) Visibility.Visible));

    internal string Placeholder
    {
      get => (string) this.GetValue(InputBox.PlaceholderProperty);
      set => this.SetValue(InputBox.PlaceholderProperty, (object) value);
    }

    internal FontStyle PlaceholderStyle
    {
      get => (FontStyle) this.GetValue(InputBox.PlaceholderStyleProperty);
      set => this.SetValue(InputBox.PlaceholderStyleProperty, (object) value);
    }

    internal Brush PlaceholderForeground
    {
      get => (Brush) this.GetValue(InputBox.PlaceholderForegroundProperty);
      set => this.SetValue(InputBox.PlaceholderForegroundProperty, (object) value);
    }

    internal CornerRadius CornerRadius
    {
      get => (CornerRadius) this.GetValue(InputBox.CornerRadiusProperty);
      set => this.SetValue(InputBox.CornerRadiusProperty, (object) value);
    }

    internal Visibility ClearButtonVisibility
    {
      get => (Visibility) this.GetValue(InputBox.ClearButtonVisibilityProperty);
      set => this.SetValue(InputBox.ClearButtonVisibilityProperty, (object) value);
    }

    internal event EventHandler<string> Submitted;

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      if (this.GetTemplateChild("ClearButton") is Border templateChild)
        templateChild.PreviewMouseDown += (MouseButtonEventHandler) ((sender, e) => this.Text = "");
      this.KeyDown += (KeyEventHandler) ((sender, e) =>
      {
        if (!e.IsDown || e.Key != Key.Return)
          return;
        EventHandler<string> submitted = this.Submitted;
        if (submitted == null)
          return;
        submitted((object) this, this.Text);
      });
    }
  }
}
