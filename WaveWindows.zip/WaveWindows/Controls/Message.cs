﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.Message
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System.Windows;
using System.Windows.Controls;

#nullable disable
namespace WaveWindows.Controls
{
  internal class Message : ListViewItem
  {
    internal static readonly DependencyProperty TextProperty = DependencyProperty.Register(nameof (Text), typeof (string), typeof (Message), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty ReverseProperty = DependencyProperty.Register(nameof (Reverse), typeof (bool), typeof (Message), (PropertyMetadata) new FrameworkPropertyMetadata((object) false));

    internal string Text
    {
      get => (string) this.GetValue(Message.TextProperty);
      set => this.SetValue(Message.TextProperty, (object) value);
    }

    internal bool Reverse
    {
      get => (bool) this.GetValue(Message.ReverseProperty);
      set => this.SetValue(Message.ReverseProperty, (object) value);
    }

    public override void OnApplyTemplate() => base.OnApplyTemplate();
  }
}
