﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.UnhandledExceptionError
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;

#nullable disable
namespace WaveWindows.Controls
{
  internal class UnhandledExceptionError : UserControl
  {
    internal static readonly DependencyProperty ImageSourceProperty = DependencyProperty.Register(nameof (ImageSource), typeof (ImageSource), typeof (UnhandledExceptionError), (PropertyMetadata) new FrameworkPropertyMetadata((PropertyChangedCallback) null));
    internal static readonly DependencyProperty TitleProperty = DependencyProperty.Register(nameof (Title), typeof (string), typeof (UnhandledExceptionError), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty MessageProperty = DependencyProperty.Register(nameof (Message), typeof (string), typeof (UnhandledExceptionError), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty CornerRadiusProperty = DependencyProperty.Register(nameof (CornerRadius), typeof (CornerRadius), typeof (UnhandledExceptionError), (PropertyMetadata) new FrameworkPropertyMetadata((object) new CornerRadius(0.0, 0.0, 0.0, 0.0)));

    internal ImageSource ImageSource
    {
      get => (ImageSource) this.GetValue(UnhandledExceptionError.ImageSourceProperty);
      set => this.SetValue(UnhandledExceptionError.ImageSourceProperty, (object) value);
    }

    internal string Title
    {
      get => (string) this.GetValue(UnhandledExceptionError.TitleProperty);
      set => this.SetValue(UnhandledExceptionError.TitleProperty, (object) value);
    }

    internal string Message
    {
      get => (string) this.GetValue(UnhandledExceptionError.MessageProperty);
      set => this.SetValue(UnhandledExceptionError.MessageProperty, (object) value);
    }

    internal CornerRadius CornerRadius
    {
      get => (CornerRadius) this.GetValue(UnhandledExceptionError.CornerRadiusProperty);
      set => this.SetValue(UnhandledExceptionError.CornerRadiusProperty, (object) value);
    }

    internal void Show(BlurEffect blurEffect, string title, string message)
    {
      this.Title = title;
      this.Message = message;
      this.IsHitTestVisible = true;
      this.Animate(blurEffect);
    }

    private void Animate(BlurEffect blurEffect)
    {
      DoubleAnimation doubleAnimation1 = new DoubleAnimation();
      doubleAnimation1.To = new double?(8.0);
      doubleAnimation1.Duration = (Duration) TimeSpan.FromSeconds(0.5);
      doubleAnimation1.EasingFunction = (IEasingFunction) new QuarticEase();
      DoubleAnimation animation1 = doubleAnimation1;
      DoubleAnimation doubleAnimation2 = new DoubleAnimation();
      doubleAnimation2.To = new double?(0.75);
      doubleAnimation2.Duration = (Duration) TimeSpan.FromSeconds(0.5);
      doubleAnimation2.EasingFunction = (IEasingFunction) new QuarticEase();
      DoubleAnimation animation2 = doubleAnimation2;
      blurEffect.BeginAnimation(BlurEffect.RadiusProperty, (AnimationTimeline) animation1);
      this.BeginAnimation(UIElement.OpacityProperty, (AnimationTimeline) animation2);
    }

    public override void OnApplyTemplate() => base.OnApplyTemplate();
  }
}
