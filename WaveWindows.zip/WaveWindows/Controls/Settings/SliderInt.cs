﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.Settings.SliderInt
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

#nullable disable
namespace WaveWindows.Controls.Settings
{
  internal class SliderInt
  {
    internal int OldValue { get; set; }

    internal int NewValue { get; set; }
  }
}
