﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.Settings.Slider
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WaveWindows.Interfaces;

#nullable disable
namespace WaveWindows.Controls.Settings
{
  internal class Slider : UserControl
  {
    internal static readonly DependencyProperty TitleProperty = DependencyProperty.Register(nameof (Title), typeof (string), typeof (Slider), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty DescriptionProperty = DependencyProperty.Register(nameof (Description), typeof (string), typeof (Slider), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty ValueProperty = DependencyProperty.Register(nameof (Value), typeof (double), typeof (Slider), (PropertyMetadata) new FrameworkPropertyMetadata((object) 0.0));
    internal static readonly DependencyProperty MinValueProperty = DependencyProperty.Register(nameof (MinValue), typeof (double), typeof (Slider), (PropertyMetadata) new FrameworkPropertyMetadata((object) 0.0));
    internal static readonly DependencyProperty MaxValueProperty = DependencyProperty.Register(nameof (MaxValue), typeof (double), typeof (Slider), (PropertyMetadata) new FrameworkPropertyMetadata((object) 0.0));

    internal string Title
    {
      get => (string) this.GetValue(Slider.TitleProperty);
      set => this.SetValue(Slider.TitleProperty, (object) value);
    }

    internal string Description
    {
      get => (string) this.GetValue(Slider.DescriptionProperty);
      set => this.SetValue(Slider.DescriptionProperty, (object) value);
    }

    internal double Value
    {
      get => (double) this.GetValue(Slider.ValueProperty);
      set
      {
        this.SetValue(Slider.ValueProperty, (object) value);
        EventHandler<SliderChangedEvent> changed = this.Changed;
        if (changed == null)
          return;
        changed((object) this, new SliderChangedEvent(this.Value, value));
      }
    }

    internal double MinValue
    {
      get => (double) this.GetValue(Slider.MinValueProperty);
      set => this.SetValue(Slider.MinValueProperty, (object) value);
    }

    internal double MaxValue
    {
      get => (double) this.GetValue(Slider.MaxValueProperty);
      set => this.SetValue(Slider.MaxValueProperty, (object) value);
    }

    private void Render()
    {
      TextBlock templateChild1 = this.GetTemplateChild("TextValue") as TextBlock;
      Border templateChild2 = this.GetTemplateChild("ValueIndicator") as Border;
      if (templateChild1 == null)
        throw new ArgumentNullException("TextValue");
      if (templateChild2 == null)
        throw new ArgumentNullException("ValueIndicator");
      double To = Math.Round((this.Value - this.MinValue) / (this.MaxValue - this.MinValue) * (templateChild2.Parent as Grid).ActualWidth);
      templateChild2.WidthAnimation(1.5, To, 17.5);
      templateChild1.Text = this.Value.ToString();
    }

    internal event EventHandler<SliderChangedEvent> Changed;

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      Border Hitbox = this.GetTemplateChild("Hitbox") as Border;
      if (Hitbox == null)
        throw new ArgumentNullException("Hitbox");
      this.Loaded += (RoutedEventHandler) ((s, e) => this.Render());
      this.Changed += (EventHandler<SliderChangedEvent>) ((s, e) => this.Render());
      Hitbox.MouseLeftButtonDown += (MouseButtonEventHandler) (async (s, e) =>
      {
        while (Mouse.LeftButton == MouseButtonState.Pressed)
        {
          this.Value = Math.Floor((this.MinValue + (this.MaxValue - this.MinValue) * Math.Min(Math.Max(Mouse.GetPosition((IInputElement) Hitbox).X, 0.0), Hitbox.ActualWidth) / Hitbox.ActualWidth) * 1.0) / 1.0;
          await Task.Delay(33);
        }
      });
    }
  }
}
