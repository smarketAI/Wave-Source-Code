﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.Settings.CheckBox
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

#nullable disable
namespace WaveWindows.Controls.Settings
{
  internal class CheckBox : UserControl
  {
    internal static readonly DependencyProperty TitleProperty = DependencyProperty.Register(nameof (Title), typeof (string), typeof (CheckBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty DescriptionProperty = DependencyProperty.Register(nameof (Description), typeof (string), typeof (CheckBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty IsCheckedProperty = DependencyProperty.Register(nameof (IsChecked), typeof (bool), typeof (CheckBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) false));

    internal string Title
    {
      get => (string) this.GetValue(CheckBox.TitleProperty);
      set => this.SetValue(CheckBox.TitleProperty, (object) value);
    }

    internal string Description
    {
      get => (string) this.GetValue(CheckBox.DescriptionProperty);
      set => this.SetValue(CheckBox.DescriptionProperty, (object) value);
    }

    internal bool IsChecked
    {
      get => (bool) this.GetValue(CheckBox.IsCheckedProperty);
      set
      {
        this.SetValue(CheckBox.IsCheckedProperty, (object) value);
        EventHandler<CheckBoxChangedEvent> eventHandler = this.Checked;
        if (eventHandler == null)
          return;
        eventHandler((object) this, new CheckBoxChangedEvent(value));
      }
    }

    internal event EventHandler<CheckBoxChangedEvent> Checked;

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      if (!(this.GetTemplateChild("Hitbox") is Border templateChild))
        throw new ArgumentNullException("Hitbox");
      templateChild.MouseLeftButtonDown += (MouseButtonEventHandler) ((sender, e) => this.IsChecked = !this.IsChecked);
    }
  }
}
