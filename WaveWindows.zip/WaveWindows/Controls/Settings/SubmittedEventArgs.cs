﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.Settings.SubmittedEventArgs
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;

#nullable disable
namespace WaveWindows.Controls.Settings
{
  internal class SubmittedEventArgs : EventArgs
  {
    internal string Text { get; set; }

    internal SubmittedEventArgs(string text) => this.Text = text;
  }
}
