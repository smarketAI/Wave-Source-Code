﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.Settings.InputBox
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

#nullable disable
namespace WaveWindows.Controls.Settings
{
  internal class InputBox : UserControl
  {
    internal static readonly DependencyProperty TitleProperty = DependencyProperty.Register(nameof (Title), typeof (string), typeof (InputBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty DescriptionProperty = DependencyProperty.Register(nameof (Description), typeof (string), typeof (InputBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty PlaceholderProperty = DependencyProperty.Register(nameof (Placeholder), typeof (string), typeof (InputBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty PlaceholderStyleProperty = DependencyProperty.Register(nameof (PlaceholderStyle), typeof (FontStyle), typeof (InputBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) FontStyles.Normal));
    internal static readonly DependencyProperty PlaceholderForegroundProperty = DependencyProperty.Register(nameof (PlaceholderForeground), typeof (Brush), typeof (InputBox), (PropertyMetadata) new FrameworkPropertyMetadata((object) new SolidColorBrush((Color) ColorConverter.ConvertFromString("#FFFFFF"))));

    internal string Title
    {
      get => (string) this.GetValue(InputBox.TitleProperty);
      set => this.SetValue(InputBox.TitleProperty, (object) value);
    }

    internal string Description
    {
      get => (string) this.GetValue(InputBox.DescriptionProperty);
      set => this.SetValue(InputBox.DescriptionProperty, (object) value);
    }

    internal string Placeholder
    {
      get => (string) this.GetValue(InputBox.PlaceholderProperty);
      set => this.SetValue(InputBox.PlaceholderProperty, (object) value);
    }

    internal FontStyle PlaceholderStyle
    {
      get => (FontStyle) this.GetValue(InputBox.PlaceholderStyleProperty);
      set => this.SetValue(InputBox.PlaceholderStyleProperty, (object) value);
    }

    internal Brush PlaceholderForeground
    {
      get => (Brush) this.GetValue(InputBox.PlaceholderForegroundProperty);
      set => this.SetValue(InputBox.PlaceholderForegroundProperty, (object) value);
    }

    internal event EventHandler<SubmittedEventArgs> Submitted;

    public override void OnApplyTemplate()
    {
      base.OnApplyTemplate();
      WaveWindows.Controls.InputBox InputBox = this.GetTemplateChild(nameof (InputBox)) as WaveWindows.Controls.InputBox;
      if (InputBox == null)
        throw new ArgumentNullException(nameof (InputBox));
      InputBox.KeyDown += (KeyEventHandler) ((s, e) =>
      {
        if (!e.IsDown || e.Key != Key.Return)
          return;
        EventHandler<SubmittedEventArgs> submitted = this.Submitted;
        if (submitted == null)
          return;
        submitted((object) this, new SubmittedEventArgs(InputBox.Text));
      });
    }
  }
}
