﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.Toast.Notification
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

#nullable disable
namespace WaveWindows.Controls.Toast
{
  internal class Notification : UserControl
  {
    internal static readonly DependencyProperty TitleProperty = DependencyProperty.Register(nameof (Title), typeof (string), typeof (Notification), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty DescriptionProperty = DependencyProperty.Register(nameof (Description), typeof (string), typeof (Notification), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty FooterProperty = DependencyProperty.Register(nameof (Footer), typeof (string), typeof (Notification), (PropertyMetadata) new FrameworkPropertyMetadata((object) ""));
    internal static readonly DependencyProperty IconProperty = DependencyProperty.Register(nameof (Icon), typeof (ImageSource), typeof (Notification), (PropertyMetadata) new FrameworkPropertyMetadata((PropertyChangedCallback) null));
    internal static readonly DependencyProperty IconMarginProperty = DependencyProperty.Register(nameof (IconMargin), typeof (Thickness), typeof (Notification), (PropertyMetadata) new FrameworkPropertyMetadata((object) new Thickness(0.0)));
    internal static readonly DependencyProperty PrimaryColorProperty = DependencyProperty.Register(nameof (PrimaryColor), typeof (Brush), typeof (Notification), (PropertyMetadata) new FrameworkPropertyMetadata((object) Brushes.Transparent));
    internal static readonly DependencyProperty SecondaryColorProperty = DependencyProperty.Register(nameof (SecondaryColor), typeof (Brush), typeof (Notification), (PropertyMetadata) new FrameworkPropertyMetadata((object) Brushes.Transparent));
    internal static readonly DependencyProperty TertiaryColorProperty = DependencyProperty.Register(nameof (TertiaryColor), typeof (Brush), typeof (Notification), (PropertyMetadata) new FrameworkPropertyMetadata((object) Brushes.Transparent));

    internal string Title
    {
      get => (string) this.GetValue(Notification.TitleProperty);
      set => this.SetValue(Notification.TitleProperty, (object) value);
    }

    internal string Description
    {
      get => (string) this.GetValue(Notification.DescriptionProperty);
      set => this.SetValue(Notification.DescriptionProperty, (object) value);
    }

    internal string Footer
    {
      get => (string) this.GetValue(Notification.FooterProperty);
      set => this.SetValue(Notification.FooterProperty, (object) value);
    }

    internal ImageSource Icon
    {
      get => (ImageSource) this.GetValue(Notification.IconProperty);
      set => this.SetValue(Notification.IconProperty, (object) value);
    }

    internal Thickness IconMargin
    {
      get => (Thickness) this.GetValue(Notification.IconMarginProperty);
      set => this.SetValue(Notification.IconMarginProperty, (object) value);
    }

    internal Brush PrimaryColor
    {
      get => (Brush) this.GetValue(Notification.PrimaryColorProperty);
      set => this.SetValue(Notification.PrimaryColorProperty, (object) value);
    }

    internal Brush SecondaryColor
    {
      get => (Brush) this.GetValue(Notification.SecondaryColorProperty);
      set => this.SetValue(Notification.SecondaryColorProperty, (object) value);
    }

    internal Brush TertiaryColor
    {
      get => (Brush) this.GetValue(Notification.TertiaryColorProperty);
      set => this.SetValue(Notification.TertiaryColorProperty, (object) value);
    }

    internal bool Dismissed { get; set; }

    public override void OnApplyTemplate() => base.OnApplyTemplate();
  }
}
