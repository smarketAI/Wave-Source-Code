﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Controls.Toast.Container
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using WaveWindows.Interfaces;

#nullable disable
namespace WaveWindows.Controls.Toast
{
  internal class Container : StackPanel
  {
    internal static readonly DependencyProperty IntervalProperty = DependencyProperty.Register(nameof (Interval), typeof (double), typeof (Container), (PropertyMetadata) new FrameworkPropertyMetadata((object) 5.0));
    internal static readonly DependencyProperty ReverseProperty = DependencyProperty.Register(nameof (Reverse), typeof (bool), typeof (Container), (PropertyMetadata) new FrameworkPropertyMetadata((object) false));

    internal double Interval
    {
      get => (double) this.GetValue(Container.IntervalProperty);
      set => this.SetValue(Container.IntervalProperty, (object) value);
    }

    internal bool Reverse
    {
      get => (bool) this.GetValue(Container.ReverseProperty);
      set => this.SetValue(Container.ReverseProperty, (object) value);
    }

    private void AddNotification(Notification toast)
    {
      if (this.Reverse)
        this.Children.Insert(0, (UIElement) toast);
      else
        this.Children.Add((UIElement) toast);
      toast.ScaleXAnimation(1.5, 1.0, 17.5);
      toast.ScaleYAnimation(1.5, 1.0, 17.5);
      toast.OpacityAnimation(0.5, 1.0, (Action) (() =>
      {
        if (toast.Dismissed)
          return;
        await Task.Delay(TimeSpan.FromSeconds(this.Interval));
        this.RemoveNotification(toast);
      }));
    }

    private void RemoveNotification(Notification toast)
    {
      if (toast.Dismissed)
        return;
      toast.Dismissed = true;
      toast.ScaleXAnimation(1.5, 0.95, 17.5);
      toast.ScaleYAnimation(1.5, 0.95, 17.5);
      toast.OpacityAnimation(0.2, 0.0, (Action) (() => this.Children.Remove((UIElement) toast)));
    }

    internal void RegisterNotification(
      string Title,
      string Description,
      string Footer,
      Action action,
      string Style)
    {
      Notification notification = new Notification();
      notification.Title = Title;
      notification.Description = Description;
      notification.Footer = Footer;
      notification.Opacity = 0.0;
      notification.RenderTransformOrigin = new Point(0.5, 0.5);
      notification.RenderTransform = (Transform) new ScaleTransform(0.95, 0.95);
      notification.Style = (Style) this.FindResource((object) Style);
      Notification Toast = notification;
      Toast.MouseDown += (MouseButtonEventHandler) ((sender, e) =>
      {
        this.RemoveNotification(Toast);
        if (action == null)
          return;
        this.Dispatcher.Invoke(action);
      });
      this.AddNotification(Toast);
    }

    internal void Success(string Title, Action action = null)
    {
      this.RegisterNotification(Title, "", "", action, "SuccessToastNotification");
    }

    internal void Success(string Title, string Description, Action action = null)
    {
      this.RegisterNotification(Title, Description, "", action, "SuccessToastNotification");
    }

    internal void Success(string Title, string Description, string Footer, Action action = null)
    {
      this.RegisterNotification(Title, Description, Footer, action, "SuccessToastNotification");
    }

    internal void Error(string Title, Action action = null)
    {
      this.RegisterNotification(Title, "", "", action, "ErrorToastNotification");
    }

    internal void Error(string Title, string Description, Action action = null)
    {
      this.RegisterNotification(Title, Description, "", action, "ErrorToastNotification");
    }

    internal void Error(string Title, string Description, string Footer, Action action = null)
    {
      this.RegisterNotification(Title, Description, Footer, action, "ErrorToastNotification");
    }

    internal void Info(string Title, Action action = null)
    {
      this.RegisterNotification(Title, "", "", action, "InfoToastNotification");
    }

    internal void Info(string Title, string Description, Action action = null)
    {
      this.RegisterNotification(Title, Description, "", action, "InfoToastNotification");
    }

    internal void Info(string Title, string Description, string Footer, Action action = null)
    {
      this.RegisterNotification(Title, Description, Footer, action, "InfoToastNotification");
    }

    internal void Warning(string Title, Action action = null)
    {
      this.RegisterNotification(Title, "", "", action, "WarningToastNotification");
    }

    internal void Warning(string Title, string Description, Action action = null)
    {
      this.RegisterNotification(Title, Description, "", action, "WarningToastNotification");
    }

    internal void Warning(string Title, string Description, string Footer, Action action = null)
    {
      this.RegisterNotification(Title, Description, Footer, action, "WarningToastNotification");
    }

    public override void OnApplyTemplate() => base.OnApplyTemplate();
  }
}
