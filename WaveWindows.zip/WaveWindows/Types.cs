﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Types
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using Newtonsoft.Json;
using System;
using System.Collections.Generic;

#nullable disable
namespace WaveWindows
{
  internal class Types
  {
    internal class ClientBehaviour
    {
      internal class ClientEmittedEventArgs : EventArgs
      {
        internal string OpCode { get; set; }

        internal object Data { get; set; }

        internal ClientEmittedEventArgs(string OpCode, object Data)
        {
          this.OpCode = OpCode;
          this.Data = Data;
        }
      }

      internal class ClientMessage
      {
        [JsonProperty("op")]
        internal string OpCode { get; set; }

        [JsonProperty("data")]
        internal object Data { get; set; }
      }

      internal class ClientIdentity
      {
        [JsonProperty("process")]
        internal Types.ClientBehaviour.ClientIdentity.ClientObject Process { get; set; }

        [JsonProperty("player")]
        internal Types.ClientBehaviour.ClientIdentity.ClientObject Player { get; set; }

        [JsonProperty("game")]
        internal Types.ClientBehaviour.ClientIdentity.ClientObject Game { get; set; }

        internal class ClientObject
        {
          [JsonProperty("id")]
          internal string Id { get; set; }

          [JsonProperty("name")]
          internal string Name { get; set; }
        }
      }

      internal class ClientScript
      {
        [JsonProperty("name")]
        internal string Name { get; set; }

        [JsonProperty("script")]
        internal string Script { get; set; }
      }

      internal class ClientError
      {
        [JsonProperty("type")]
        internal string Type { get; set; }

        [JsonProperty("error_code")]
        internal int Code { get; set; }

        [JsonProperty("error_message")]
        internal string Message { get; set; }

        [JsonProperty("logout_clear_session")]
        internal bool ClearSession { get; set; }
      }
    }

    internal class RobloxClientVersion
    {
      [JsonProperty("version")]
      internal string Version { get; set; }

      [JsonProperty("clientVersionUpload")]
      internal string Upload { get; set; }

      [JsonProperty("bootstrapperVersion")]
      internal string Bootstrapper { get; set; }
    }

    internal class RobloxThumbnail
    {
      internal class ThumbnailResponse
      {
        [JsonProperty("data")]
        internal List<Types.RobloxThumbnail.ThumbnailData> Data { get; set; }
      }

      internal class ThumbnailData
      {
        [JsonProperty("targetId")]
        internal long TargetId { get; set; }

        [JsonProperty("state")]
        internal string State { get; set; }

        [JsonProperty("imageUrl")]
        internal string Image { get; set; }

        [JsonProperty("version")]
        internal string Version { get; set; }
      }
    }

    internal class WaveAPI
    {
      internal class User
      {
        [JsonProperty("id")]
        internal string Id { get; set; }

        [JsonProperty("products")]
        internal List<Types.WaveAPI.Product> Products { get; set; }
      }

      internal class Product
      {
        [JsonProperty("uuid")]
        internal string Id { get; set; }

        [JsonProperty("expiration")]
        internal long Timestamp { get; set; }

        [JsonProperty("product")]
        internal string Name { get; set; }
      }

      internal class ErrorResponse
      {
        [JsonProperty("code")]
        internal string Code { get; set; }

        [JsonProperty("message")]
        internal string Error { get; set; }

        [JsonProperty("userFacingMessage")]
        internal string Message { get; set; }
      }

      internal class PromptResponse
      {
        [JsonProperty("message")]
        internal string Message { get; set; }
      }

      internal class HistoryResponse
      {
        [JsonProperty("messages")]
        internal List<Types.WaveAPI.Message> Messages { get; set; }
      }

      internal class Message
      {
        [JsonProperty("role")]
        internal string Role { get; set; }

        [JsonProperty("content")]
        internal string Content { get; set; }
      }
    }
  }
}
