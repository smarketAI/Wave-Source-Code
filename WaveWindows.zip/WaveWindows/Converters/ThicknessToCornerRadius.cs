﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Converters.ThicknessToCornerRadius
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

#nullable disable
namespace WaveWindows.Converters
{
  internal class ThicknessToCornerRadius : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      return value is Thickness thickness ? (object) new CornerRadius(thickness.Left, thickness.Top, thickness.Right, thickness.Bottom) : (object) new CornerRadius(0.0);
    }

    public object ConvertBack(
      object value,
      Type targetType,
      object parameter,
      CultureInfo culture)
    {
      if (value is CornerRadius cornerRadius)
        return (object) new Thickness(cornerRadius.TopLeft, cornerRadius.BottomLeft, cornerRadius.TopRight, cornerRadius.BottomRight);
      throw new InvalidOperationException("ThicknessToCornerRadius.ConvertBack");
    }
  }
}
