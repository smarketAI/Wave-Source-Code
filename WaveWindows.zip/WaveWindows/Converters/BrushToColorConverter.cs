﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Converters.BrushToColorConverter
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

#nullable disable
namespace WaveWindows.Converters
{
  internal class BrushToColorConverter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
      return value is SolidColorBrush solidColorBrush ? (object) solidColorBrush.Color : (object) Colors.Transparent;
    }

    public object ConvertBack(
      object value,
      Type targetType,
      object parameter,
      CultureInfo culture)
    {
      return value is Color color ? (object) new SolidColorBrush(color) : throw new InvalidOperationException("BrushToColorConverter.ConvertBack");
    }
  }
}
