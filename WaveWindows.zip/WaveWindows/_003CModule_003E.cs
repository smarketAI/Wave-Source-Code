﻿// Decompiled with JetBrains decompiler
// Type: <Module>
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using Costura;

#nullable disable
internal class \u003CModule\u003E
{
  static \u003CModule\u003E() => AssemblyLoader.Attach();
}
