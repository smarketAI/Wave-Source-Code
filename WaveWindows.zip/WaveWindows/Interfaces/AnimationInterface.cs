﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Interfaces.AnimationInterface
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;

#nullable disable
namespace WaveWindows.Interfaces
{
  internal static class AnimationInterface
  {
    internal static void ScaleXAnimation(
      this UIElement Element,
      double Duration,
      double To,
      double Springiness,
      Action OnCompleted = null)
    {
      DoubleAnimation doubleAnimation = new DoubleAnimation();
      doubleAnimation.To = new double?(To);
      doubleAnimation.Duration = (Duration) TimeSpan.FromSeconds(Duration);
      doubleAnimation.EasingFunction = (IEasingFunction) new ElasticEase()
      {
        Springiness = Springiness
      };
      DoubleAnimation animation = doubleAnimation;
      if (OnCompleted != null)
        animation.Completed += (EventHandler) ((s, e) => OnCompleted());
      Element.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, (AnimationTimeline) animation);
    }

    internal static void ScaleYAnimation(
      this UIElement Element,
      double Duration,
      double To,
      double Springiness,
      Action OnCompleted = null)
    {
      DoubleAnimation doubleAnimation = new DoubleAnimation();
      doubleAnimation.To = new double?(To);
      doubleAnimation.Duration = (Duration) TimeSpan.FromSeconds(Duration);
      doubleAnimation.EasingFunction = (IEasingFunction) new ElasticEase()
      {
        Springiness = Springiness
      };
      DoubleAnimation animation = doubleAnimation;
      if (OnCompleted != null)
        animation.Completed += (EventHandler) ((s, e) => OnCompleted());
      Element.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, (AnimationTimeline) animation);
    }

    internal static void OpacityAnimation(
      this UIElement Element,
      double Duration,
      double To,
      Action OnCompleted = null)
    {
      DoubleAnimation doubleAnimation = new DoubleAnimation();
      doubleAnimation.To = new double?(To);
      doubleAnimation.Duration = (Duration) TimeSpan.FromSeconds(Duration);
      DoubleAnimation animation = doubleAnimation;
      if (OnCompleted != null)
        animation.Completed += (EventHandler) ((s, e) => OnCompleted());
      Element.BeginAnimation(UIElement.OpacityProperty, (AnimationTimeline) animation);
    }

    internal static void WidthAnimation(
      this FrameworkElement Element,
      double Duration,
      double To,
      double Springiness)
    {
      DoubleAnimation doubleAnimation = new DoubleAnimation();
      doubleAnimation.To = new double?(To);
      doubleAnimation.Duration = (Duration) TimeSpan.FromSeconds(Duration);
      doubleAnimation.EasingFunction = (IEasingFunction) new ElasticEase()
      {
        Springiness = Springiness
      };
      DoubleAnimation animation = doubleAnimation;
      Element.BeginAnimation(FrameworkElement.WidthProperty, (AnimationTimeline) animation);
    }
  }
}
