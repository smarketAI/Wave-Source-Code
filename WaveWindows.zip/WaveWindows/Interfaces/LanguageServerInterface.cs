﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Interfaces.LanguageServerInterface
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

#nullable disable
namespace WaveWindows.Interfaces
{
  internal static class LanguageServerInterface
  {
    internal static readonly List<string> Directories = new List<string>()
    {
      "server",
      "shared",
      "shared\\bin",
      "shared\\configuration",
      "shared\\themes"
    };
    internal static readonly List<string> Files = new List<string>()
    {
      "https://github.com/dxgi/wave-binaries/raw/main/language-server-protocol/node.exe",
      "https://github.com/dxgi/wave-binaries/raw/main/language-server-protocol/server/codicon.ttf",
      "https://github.com/dxgi/wave-binaries/raw/main/language-server-protocol/server/index.js",
      "https://github.com/dxgi/wave-binaries/raw/main/language-server-protocol/shared/bin/en-us.json",
      "https://github.com/dxgi/wave-binaries/raw/main/language-server-protocol/shared/bin/globalTypes.d.luau",
      "https://github.com/dxgi/wave-binaries/raw/main/language-server-protocol/shared/bin/wave-luau.exe",
      "https://github.com/dxgi/wave-binaries/raw/main/language-server-protocol/shared/bin/wave.d.luau",
      "https://github.com/dxgi/wave-binaries/raw/main/language-server-protocol/shared/configuration/default.json",
      "https://github.com/dxgi/wave-binaries/raw/main/language-server-protocol/shared/themes/wave.json"
    };
    internal static readonly string BaseDirectory = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\Luau Language Server";

    internal static async Task<Process> TryLaunch()
    {
      await LanguageServerInterface.Verify();
      return new Process()
      {
        StartInfo = new ProcessStartInfo()
        {
          FileName = Path.Combine(LanguageServerInterface.BaseDirectory, "node.exe"),
          WorkingDirectory = LanguageServerInterface.BaseDirectory,
          Arguments = string.Format("server --process-id={0}", (object) Process.GetCurrentProcess().Id),
          CreateNoWindow = true,
          WindowStyle = ProcessWindowStyle.Hidden
        },
        EnableRaisingEvents = true
      };
    }

    internal static async Task Verify()
    {
      List<Task> taskList = new List<Task>();
      foreach (string directory in LanguageServerInterface.Directories)
      {
        string path = LanguageServerInterface.BaseDirectory + "\\" + directory;
        if (!Directory.Exists(path))
          Directory.CreateDirectory(path);
      }
      foreach (string file in LanguageServerInterface.Files)
      {
        string fileName = ((IEnumerable<string>) file.Split('/')).Last<string>();
        string str = LanguageServerInterface.GetFileDirectory(file) + "\\" + fileName;
        if (!System.IO.File.Exists(str))
          taskList.Add(LanguageServerInterface.DownloadFileAsync(fileName, str, file));
      }
      await Task.WhenAll((IEnumerable<Task>) taskList);
    }

    internal static string GetFileDirectory(string path)
    {
      if (path.Contains("server/"))
        return LanguageServerInterface.BaseDirectory + "\\server";
      if (path.Contains("shared/bin"))
        return LanguageServerInterface.BaseDirectory + "\\shared\\bin";
      if (path.Contains("shared/configuration"))
        return LanguageServerInterface.BaseDirectory + "\\shared\\configuration";
      return path.Contains("shared/themes") ? LanguageServerInterface.BaseDirectory + "\\shared\\themes" : LanguageServerInterface.BaseDirectory;
    }

    internal static async Task DownloadFileAsync(string fileName, string filePath, string fileUrl)
    {
      using (HttpClient client = new HttpClient())
      {
        HttpResponseMessage async = await client.GetAsync(fileUrl);
        if (async.StatusCode != HttpStatusCode.OK)
          throw new Exception("Failed to download " + fileName);
        System.IO.File.WriteAllBytes(filePath, await async.Content.ReadAsByteArrayAsync());
      }
    }
  }
}
