﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Interfaces.InjectorInterface
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using Newtonsoft.Json;
using RestSharp;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using WaveWindows.Modules;

#nullable enable
namespace WaveWindows.Interfaces
{
  internal class InjectorInterface
  {
    internal static readonly 
    #nullable disable
    string[] Files = new string[2]
    {
      "Injector.exe",
      "Wave.dll"
    };
    internal static readonly string BaseDirectory = Path.GetTempPath();
    internal static readonly string InjectorPath = InjectorInterface.BaseDirectory + "\\Injector.exe";
    internal static readonly string WavePath = InjectorInterface.BaseDirectory + "\\Wave.dll";
    internal static readonly HttpClient Client = new HttpClient();
    internal static string Version = "";

    internal static Process GetInjector(int processId)
    {
      return new Process()
      {
        StartInfo = new ProcessStartInfo()
        {
          Verb = "runas",
          FileName = InjectorInterface.BaseDirectory + "\\Injector.exe",
          WorkingDirectory = "./bin",
          Arguments = string.Format("{0}", (object) processId),
          UseShellExecute = false,
          CreateNoWindow = true,
          RedirectStandardError = true,
          RedirectStandardOutput = true
        }
      };
    }

    internal static async Task GetBinariesAsync(Action<string, double> callback)
    {
      InjectorInterface.Version = await InjectorInterface.GetVersionAsync();
      if (System.IO.File.Exists(InjectorInterface.InjectorPath))
      {
        if (string.IsNullOrEmpty(Registry.Configuration.FirstHash))
        {
          System.IO.File.Delete(InjectorInterface.InjectorPath);
          return;
        }
        if (await InjectorInterface.GetFileHashAsync("Injector.exe") != Registry.Configuration.FirstHash)
          System.IO.File.Delete(InjectorInterface.InjectorPath);
      }
      if (System.IO.File.Exists(InjectorInterface.BaseDirectory + "\\Wave.dll"))
      {
        if (string.IsNullOrEmpty(Registry.Configuration.SecondHash))
        {
          System.IO.File.Delete(InjectorInterface.WavePath);
          return;
        }
        if (await InjectorInterface.GetFileHashAsync("Wave.dll") != Registry.Configuration.SecondHash)
          System.IO.File.Delete(InjectorInterface.WavePath);
      }
      Registry registry;
      if (!System.IO.File.Exists(InjectorInterface.InjectorPath))
      {
        await InjectorInterface.DownloadFileAsync("Injector.exe", InjectorInterface.InjectorPath, callback);
        registry = Registry.Configuration;
        registry.FirstHash = await InjectorInterface.GetFileHashAsync("Injector.exe");
        registry = (Registry) null;
      }
      if (System.IO.File.Exists(InjectorInterface.WavePath))
        return;
      await InjectorInterface.DownloadFileAsync("Wave.dll", InjectorInterface.WavePath, callback);
      registry = Registry.Configuration;
      registry.SecondHash = await InjectorInterface.GetFileHashAsync("Wave.dll");
      registry = (Registry) null;
    }

    private static async Task<string> GetFileHashAsync(string file)
    {
      HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Head, "https://cdn.getwave.gg/versions/" + InjectorInterface.Version + "/" + file);
      HttpResponseMessage httpResponseMessage = await InjectorInterface.Client.SendAsync(request);
      httpResponseMessage.EnsureSuccessStatusCode();
      string str = httpResponseMessage.StatusCode == HttpStatusCode.OK ? httpResponseMessage.Headers.GetValues("etag").FirstOrDefault<string>() : throw new Exception("Failed to get " + file + " hash.");
      return !string.IsNullOrEmpty(str) ? str : throw new Exception("Failed to get " + file + " hash.");
    }

    internal static async Task<string> GetVersionAsync()
    {
      HttpResponseMessage async = await InjectorInterface.Client.GetAsync("https://clientsettingscdn.roblox.com/v2/client-version/WindowsPlayer");
      async.EnsureSuccessStatusCode();
      return ((async.StatusCode == HttpStatusCode.OK ? JsonConvert.DeserializeObject<Types.RobloxClientVersion>(await async.Content.ReadAsStringAsync()) : throw new Exception("Failed to get Roblox version.")) ?? throw new Exception("Failed to parse Roblox version.")).Upload;
    }

    private static async Task DownloadFileAsync(
      string fileName,
      string filePath,
      Action<string, double> callback)
    {
      using (RestClient client = new RestClient("https://cdn.getwave.gg/versions/" + InjectorInterface.Version, (ConfigureRestClient) null, (ConfigureHeaders) null, (ConfigureSerialization) null))
      {
        RestRequest restRequest = new RestRequest(fileName, (Method) 0);
        RestRequestExtensions.AddParameter<long>(restRequest, "t", DateTime.UtcNow.Ticks, true);
        RestResponse restResponse = await client.ExecuteAsync(restRequest, new CancellationToken());
        if (((RestResponseBase) restResponse).StatusCode != HttpStatusCode.OK)
          throw new Exception(string.Format("Failed to download {0} ({1})", (object) fileName, (object) ((RestResponseBase) restResponse).StatusCode));
        int totalBytes = ((RestResponseBase) restResponse).RawBytes.Length;
        double downloadedBytes = 0.0;
        using (MemoryStream responseStream = new MemoryStream(((RestResponseBase) restResponse).RawBytes))
        {
          using (FileStream fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
          {
            byte[] buffer = new byte[8192];
            int bytesRead = 0;
            while (true)
            {
              if ((bytesRead = await responseStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
              {
                await fileStream.WriteAsync(buffer, 0, bytesRead);
                downloadedBytes += (double) bytesRead;
                double progress = downloadedBytes / (double) totalBytes * 100.0;
                Application.Current.Dispatcher.Invoke((Action) (() => callback(fileName, progress)));
              }
              else
                break;
            }
            buffer = (byte[]) null;
          }
        }
      }
    }
  }
}
