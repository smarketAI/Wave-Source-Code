﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Interfaces.WaveInterface
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using Newtonsoft.Json;
using RestSharp;
using System;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

#nullable enable
namespace WaveWindows.Interfaces
{
  internal static class WaveInterface
  {
    private static readonly 
    #nullable disable
    RestClient Client = new RestClient("https://api.getwave.gg/v1", (ConfigureRestClient) null, (ConfigureHeaders) null, (ConfigureSerialization) null);

    internal static async Task<string> Login(string identity, string password)
    {
      RestRequest restRequest = RestRequestExtensions.AddHeader(new RestRequest("auth/login", (Method) 1), "Content-Type", "application/json");
      RestRequestExtensions.AddJsonBody<string>(restRequest, JsonConvert.SerializeObject((object) new
      {
        identity = identity,
        password = password
      }), (ContentType) null);
      RestResponse restResponse = await WaveInterface.Client.ExecuteAsync(restRequest, new CancellationToken());
      if (((RestResponseBase) restResponse).StatusCode == (HttpStatusCode) 429)
        throw new Exception("You have exceeded the rate limit of requests. Please try again later.");
      if (((RestResponseBase) restResponse).StatusCode != HttpStatusCode.OK)
        WaveInterface.ThrowError(((RestResponseBase) restResponse).Content);
      return ((Parameter) ((RestResponseBase) restResponse).Headers.First<HeaderParameter>((Func<HeaderParameter, bool>) (header => ((Parameter) header).Name == "authorization"))).Value.ToString();
    }

    internal static async Task Register(string username, string email, string password)
    {
      RestRequest restRequest = RestRequestExtensions.AddHeader(new RestRequest("auth/register", (Method) 1), "Content-Type", "application/json");
      RestRequestExtensions.AddJsonBody<string>(restRequest, JsonConvert.SerializeObject((object) new
      {
        username = username,
        email = email,
        password = password
      }), (ContentType) null);
      RestResponse restResponse = await WaveInterface.Client.ExecuteAsync(restRequest, new CancellationToken());
      if (((RestResponseBase) restResponse).StatusCode == (HttpStatusCode) 429)
        throw new Exception("You have exceeded the rate limit of requests. Please try again later.");
      if (((RestResponseBase) restResponse).StatusCode == HttpStatusCode.OK)
        return;
      WaveInterface.ThrowError(((RestResponseBase) restResponse).Content);
    }

    internal static async Task<Types.WaveAPI.User> GetUserAsync(string session)
    {
      RestRequest restRequest = RestRequestExtensions.AddHeader(new RestRequest("user", (Method) 0), "Authorization", session);
      RestResponse restResponse = await WaveInterface.Client.ExecuteAsync(restRequest, new CancellationToken());
      if (((RestResponseBase) restResponse).StatusCode == (HttpStatusCode) 429)
        throw new Exception("You have exceeded the rate limit of requests. Please try again later.");
      if (((RestResponseBase) restResponse).StatusCode != HttpStatusCode.OK)
        WaveInterface.ThrowError(((RestResponseBase) restResponse).Content);
      return JsonConvert.DeserializeObject<Types.WaveAPI.User>(((RestResponseBase) restResponse).Content);
    }

    internal static async Task RequestPasswordReset(string identity)
    {
      RestRequest restRequest = RestRequestExtensions.AddHeader(new RestRequest("/auth/password/forgot", (Method) 1), "Content-Type", "application/json");
      RestRequestExtensions.AddJsonBody<string>(restRequest, JsonConvert.SerializeObject((object) new
      {
        identity = identity
      }), (ContentType) null);
      RestResponse restResponse = await WaveInterface.Client.ExecuteAsync(restRequest, new CancellationToken());
      if (((RestResponseBase) restResponse).StatusCode == (HttpStatusCode) 429)
        throw new Exception("You have exceeded the rate limit of requests. Please try again later.");
      if (((RestResponseBase) restResponse).StatusCode == HttpStatusCode.OK)
        return;
      WaveInterface.ThrowError(((RestResponseBase) restResponse).Content);
    }

    internal static async Task RequestEmailVerification(string identity)
    {
      RestRequest restRequest = RestRequestExtensions.AddHeader(new RestRequest("auth/email/request", (Method) 1), "Content-Type", "application/json");
      RestRequestExtensions.AddJsonBody<string>(restRequest, JsonConvert.SerializeObject((object) new
      {
        identity = identity
      }), (ContentType) null);
      RestResponse restResponse = await WaveInterface.Client.ExecuteAsync(restRequest, new CancellationToken());
      if (((RestResponseBase) restResponse).StatusCode == (HttpStatusCode) 429)
        throw new Exception("You have exceeded the rate limit of requests. Please try again later.");
      if (((RestResponseBase) restResponse).StatusCode == HttpStatusCode.OK)
        return;
      WaveInterface.ThrowError(((RestResponseBase) restResponse).Content);
    }

    internal static async Task RedeemAsync(string session, string license)
    {
      RestRequest restRequest = RestRequestExtensions.AddHeader(RestRequestExtensions.AddHeader(new RestRequest("subscription/claim", (Method) 1), "Content-Type", "application/json"), "Authorization", session);
      RestRequestExtensions.AddJsonBody<string>(restRequest, JsonConvert.SerializeObject((object) new
      {
        licenseKey = license
      }), (ContentType) null);
      RestResponse restResponse = await WaveInterface.Client.ExecuteAsync(restRequest, new CancellationToken());
      if (((RestResponseBase) restResponse).StatusCode == (HttpStatusCode) 429)
        throw new Exception("You have exceeded the rate limit of requests. Please try again later.");
      if (((RestResponseBase) restResponse).StatusCode == HttpStatusCode.OK)
        return;
      WaveInterface.ThrowError(((RestResponseBase) restResponse).Content);
    }

    internal static async Task<Types.WaveAPI.PromptResponse> SendPromptAsync(
      string session,
      string message)
    {
      RestRequest restRequest = RestRequestExtensions.AddHeader(RestRequestExtensions.AddHeader(new RestRequest("ai/chat/prompt", (Method) 1), "Content-Type", "application/json"), "Authorization", session);
      RestRequestExtensions.AddJsonBody<string>(restRequest, JsonConvert.SerializeObject((object) new
      {
        message = message
      }), (ContentType) null);
      RestResponse restResponse = await WaveInterface.Client.ExecuteAsync(restRequest, new CancellationToken());
      if (((RestResponseBase) restResponse).StatusCode == (HttpStatusCode) 429)
        throw new Exception("You have exceeded the rate limit of requests. Please try again later.");
      if (((RestResponseBase) restResponse).StatusCode != HttpStatusCode.OK)
        WaveInterface.ThrowError(((RestResponseBase) restResponse).Content);
      return ((RestResponseBase) restResponse).Content != null ? JsonConvert.DeserializeObject<Types.WaveAPI.PromptResponse>(((RestResponseBase) restResponse).Content) : throw new Exception("An unknown error has occurred. Please try again later.");
    }

    internal static async Task<Types.WaveAPI.HistoryResponse> FetchHistoryAsync(string session)
    {
      RestRequest restRequest = RestRequestExtensions.AddHeader(new RestRequest("ai/chat/history", (Method) 0), "Authorization", session);
      RestResponse restResponse = await WaveInterface.Client.ExecuteAsync(restRequest, new CancellationToken());
      if (((RestResponseBase) restResponse).StatusCode == (HttpStatusCode) 429)
        throw new Exception("You have exceeded the rate limit of requests. Please try again later.");
      if (((RestResponseBase) restResponse).StatusCode != HttpStatusCode.OK)
        WaveInterface.ThrowError(((RestResponseBase) restResponse).Content);
      return JsonConvert.DeserializeObject<Types.WaveAPI.HistoryResponse>(((RestResponseBase) restResponse).Content);
    }

    internal static async Task ClearHistoryAsync(string session)
    {
      RestRequest restRequest = RestRequestExtensions.AddHeader(RestRequestExtensions.AddHeader(new RestRequest("ai/chat", (Method) 3), "Content-Type", "application/json"), "Authorization", session);
      RestResponse restResponse = await WaveInterface.Client.ExecuteAsync(restRequest, new CancellationToken());
      if (((RestResponseBase) restResponse).StatusCode == (HttpStatusCode) 429)
        throw new Exception("You have exceeded the rate limit of requests. Please try again later.");
      if (((RestResponseBase) restResponse).StatusCode == HttpStatusCode.OK)
        return;
      WaveInterface.ThrowError(((RestResponseBase) restResponse).Content);
    }

    internal static void ThrowError(string responseContent)
    {
      throw new Exception(WaveInterface.GetError(WaveInterface.ParseError(responseContent)));
    }

    internal static Types.WaveAPI.ErrorResponse ParseError(string error)
    {
      try
      {
        return JsonConvert.DeserializeObject<Types.WaveAPI.ErrorResponse>(error);
      }
      catch
      {
        throw new Exception("Unable to establish a connection with the servers.");
      }
    }

    internal static string GetError(Types.WaveAPI.ErrorResponse error)
    {
      string code = error.Code;
      if (code != null)
      {
        switch (code.Length)
        {
          case 9:
            switch (code[8])
            {
              case '0':
                if (code == "user#0010")
                  return "The email has already been verified for this account.";
                break;
              case '1':
                switch (code)
                {
                  case "user#0001":
                    return "The user does not exist or has been terminated.";
                  case "user#0011":
                    return "Your authentication has failed. Please try again.";
                }
                break;
              case '2':
                if (code == "user#0002")
                  return "A user with that username already exists.";
                break;
              case '3':
                if (code == "user#0003")
                  return "A user with that email already exists.";
                break;
              case '4':
                if (code == "user#0004")
                  return "Usernames can only contain alphanumeric characters and one underscore.";
                break;
              case '5':
                if (code == "user#0005")
                  return "Usernames should be between 3 and 16 characters long.";
                break;
              case '6':
                if (code == "user#0006")
                  return "The email provided is invalid. Please check your spelling.";
                break;
              case '7':
                if (code == "user#0007")
                  return "The email provided exceeds RFC standards.";
                break;
              case '8':
                if (code == "user#0008")
                  return "Your username/email or password is incorrect.";
                break;
              case '9':
                if (code == "user#0009")
                  return "Your account lacks permission to access this content.";
                break;
            }
            break;
          case 10:
            if (code == "token#0001")
              return "Your current session has become invalid. Please log in again.";
            break;
          case 11:
            switch (code[10])
            {
              case '1':
                if (code == "server#0001")
                  return "An internal server error has occurred, please try again later.";
                break;
              case '2':
                if (code == "server#0002")
                  return "Access has been temporarily restricted due to exceeding the rate limit of requests.";
                break;
            }
            break;
          case 12:
            switch (code[11])
            {
              case '1':
                if (code == "session#0001")
                  return "Your current session has become invalid. Please log in again.";
                break;
              case '2':
                if (code == "session#0002")
                  return "Please verify your email address. Try check your spam or junk folders.";
                break;
              case '3':
                if (code == "session#0003")
                  return "Your account has been terminated. Please seek support for further assistance.";
                break;
            }
            break;
          case 17:
            switch (code[16])
            {
              case '1':
                if (code == "subscription#0001")
                  return "The provided license key is invalid, does not exist, or has expired.";
                break;
              case '2':
                if (code == "subscription#0002")
                  return "The license key has already been redeemed.";
                break;
              case '3':
                if (code == "subscription#0003")
                  return "An additional license cannot be claimed as this account holds an indefinite license.";
                break;
              case '4':
                if (code == "subscription#0004")
                  return "The expiration date cannot be set in the past; it must be in the future.";
                break;
              case '5':
                if (code == "subscription#0005")
                  return "The specified product does not exist or is invalid.";
                break;
            }
            break;
        }
      }
      return error.Message ?? "An unknown error has occurred. Please try again later.";
    }
  }
}
