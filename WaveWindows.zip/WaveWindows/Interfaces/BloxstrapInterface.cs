﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Interfaces.BloxstrapInterface
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;
using WaveWindows.Modules;

#nullable disable
namespace WaveWindows.Interfaces
{
  internal static class BloxstrapInterface
  {
    internal static readonly List<string> Files = new List<string>()
    {
      "https://github.com/dxgi/wave-binaries/raw/main/bloxstrap-setup/Bloxstrap.dll",
      "https://github.com/dxgi/wave-binaries/raw/main/bloxstrap-setup/Bloxstrap.exe",
      "https://github.com/dxgi/wave-binaries/raw/main/bloxstrap-setup/Bloxstrap.runtimeconfig.json",
      "https://github.com/dxgi/wave-binaries/raw/main/bloxstrap-setup/Wave-Blue.ico"
    };
    internal static readonly string Path = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\Bloxstrap";
    internal static readonly string Hash = "2F88EA7E1183D320FB2B7483DE2E860DA13DC0C0CAAF58F41A888528D78C809F";

    internal static async void Install()
    {
      if (System.IO.File.Exists(BloxstrapInterface.Path + "\\Bloxstrap.exe") && Cryptography.SHA256.GetHashFromFile(BloxstrapInterface.Path + "\\Bloxstrap.exe") == BloxstrapInterface.Hash)
        return;
      foreach (Process process in Process.GetProcessesByName("RobloxPlayerBeta"))
      {
        try
        {
          process.Kill();
        }
        catch
        {
        }
      }
      if (Directory.Exists(BloxstrapInterface.Path))
        Directory.Delete(BloxstrapInterface.Path, true);
      if (!Directory.Exists(BloxstrapInterface.Path))
        Directory.CreateDirectory(BloxstrapInterface.Path);
      List<Task> taskList = new List<Task>();
      foreach (string file in BloxstrapInterface.Files)
      {
        string fileName = ((IEnumerable<string>) file.Split('/')).Last<string>();
        string filePath = BloxstrapInterface.Path + "\\" + fileName;
        taskList.Add(BloxstrapInterface.DownloadFileAsync(fileName, filePath, file));
      }
      await Task.WhenAll(taskList.ToArray());
      System.IO.File.WriteAllText(BloxstrapInterface.Path + "\\Settings.json", JsonConvert.SerializeObject((object) new
      {
        BootstrapperStyle = 4,
        BootstrapperIcon = 8,
        BootstrapperTitle = "Wave - Launcher",
        BootstrapperIconCustomLocation = (BloxstrapInterface.Path + "\\Wave-Blue.ico"),
        Theme = 2,
        CheckForUpdates = false,
        CreateDesktopIcon = false,
        MultiInstanceLaunching = true,
        OhHeyYouFoundMe = false,
        Channel = "Live",
        ChannelChangeMode = 2,
        EnableActivityTracking = true,
        UseDiscordRichPresence = true,
        HideRPCButtons = true,
        ShowServerDetails = false,
        UseOldDeathSound = true,
        UseOldCharacterSounds = false,
        UseDisableAppPatch = false,
        UseOldAvatarBackground = false,
        CursorType = 0,
        EmojiType = 0,
        DisableFullscreenOptimizations = false
      }));
      Process.Start(BloxstrapInterface.Path + "\\Bloxstrap.exe");
      int num = (int) MessageBox.Show("Bloxstrap has been installed successfully.", "Wave - Launcher", MessageBoxButton.OK, MessageBoxImage.Asterisk);
    }

    internal static async Task DownloadFileAsync(string fileName, string filePath, string fileUrl)
    {
      using (HttpClient client = new HttpClient())
      {
        HttpResponseMessage async = await client.GetAsync(fileUrl);
        if (async.StatusCode != HttpStatusCode.OK)
          throw new Exception("Failed to download " + fileName);
        System.IO.File.WriteAllBytes(filePath, await async.Content.ReadAsByteArrayAsync());
      }
    }
  }
}
