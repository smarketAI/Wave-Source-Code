﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Interfaces.EditorInterface
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using Newtonsoft.Json;

#nullable disable
namespace WaveWindows.Interfaces
{
  internal class EditorInterface
  {
    internal class MinimapOptions
    {
      [JsonProperty("enabled")]
      internal bool Enabled { get; set; }
    }

    internal class InlayHintsOptions
    {
      [JsonProperty("enabled")]
      internal bool Enabled { get; set; }
    }

    internal class EditorOptions
    {
      [JsonProperty("minimap")]
      internal EditorInterface.MinimapOptions Minimap { get; set; }

      [JsonProperty("inlayHints")]
      internal EditorInterface.InlayHintsOptions InlayHints { get; set; }

      [JsonProperty("fontSize")]
      internal int FontSize { get; set; }

      public bool ShouldSerializeFontSize() => this.FontSize != 0;

      public override string ToString()
      {
        return JsonConvert.SerializeObject((object) this, (Formatting) 1, new JsonSerializerSettings()
        {
          NullValueHandling = (NullValueHandling) 1
        });
      }
    }
  }
}
