﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Interfaces.AdvertisementInterface
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using System;

#nullable disable
namespace WaveWindows.Interfaces
{
  internal class AdvertisementInterface
  {
    internal string Image { get; set; }

    internal string Link { get; set; }

    internal static AdvertisementInterface Random()
    {
      switch (new System.Random().Next(6))
      {
        case 0:
          return new AdvertisementInterface()
          {
            Image = "Includes/Banners/Lootlabs.png",
            Link = ""
          };
        case 1:
          return new AdvertisementInterface()
          {
            Image = "Includes/Banners/Linkvertise.jpg",
            Link = ""
          };
        case 2:
          return new AdvertisementInterface()
          {
            Image = "Includes/Banners/OceanKeys.png",
            Link = ""
          };
        case 3:
          return new AdvertisementInterface()
          {
            Image = "Includes/Banners/ProjectRain.png",
            Link = ""
          };
        case 4:
          return new AdvertisementInterface()
          {
            Image = "Includes/Banners/WavePremium.png",
            Link = ""
          };
        case 5:
          return new AdvertisementInterface()
          {
            Image = "Includes/Banners/WiiHub.png",
            Link = ""
          };
        default:
          throw new ArgumentOutOfRangeException("AdvertisementInterface.Random");
      }
    }
  }
}
