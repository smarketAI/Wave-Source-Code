﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Interfaces.ScriptBloxInterface
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using Newtonsoft.Json;
using RestSharp;
using System;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

#nullable enable
namespace WaveWindows.Interfaces
{
  internal class ScriptBloxInterface
  {
    internal static 
    #nullable disable
    RestClient Client = new RestClient("https://scriptblox.com/api", (ConfigureRestClient) null, (ConfigureHeaders) null, (ConfigureSerialization) null);

    internal static async Task<SearchResult> Search(string query, int page)
    {
      RestRequest restRequest = RestRequestExtensions.AddParameter(RestRequestExtensions.AddParameter<int>(new RestRequest("script/fetch", (Method) 0), nameof (page), page, true), "q", query, true);
      RestResponse async = await RestClientExtensions.GetAsync((IRestClient) ScriptBloxInterface.Client, restRequest, new CancellationToken());
      if (!((RestResponseBase) async).IsSuccessStatusCode)
        throw new HttpRequestException(((RestResponseBase) async).ErrorMessage);
      return JsonConvert.DeserializeObject<SearchResponse>(((RestResponseBase) async).Content, new JsonSerializerSettings()
      {
        NullValueHandling = (NullValueHandling) 1,
        MissingMemberHandling = (MissingMemberHandling) 0
      }).Result;
    }

    internal static async Task<Script> GetScript(Script script)
    {
      RestRequest restRequest = new RestRequest("script/" + script.Slug, (Method) 0);
      RestResponse async = await RestClientExtensions.GetAsync((IRestClient) ScriptBloxInterface.Client, restRequest, new CancellationToken());
      if (!((RestResponseBase) async).IsSuccessStatusCode)
        throw new HttpRequestException(((RestResponseBase) async).ErrorException.ToString());
      return JsonConvert.DeserializeObject<ScriptResult>(((RestResponseBase) async).Content, new JsonSerializerSettings()
      {
        NullValueHandling = (NullValueHandling) 1,
        MissingMemberHandling = (MissingMemberHandling) 0
      }).Script;
    }

    internal static string GetImageUrl(string Image)
    {
      return !Image.StartsWith("https://tr.rbxcdn.com") ? "https://scriptblox.com" + Image : Image;
    }

    internal static ImageSource ToImage(string url)
    {
      BitmapImage image = new BitmapImage();
      image.BeginInit();
      image.UriSource = new Uri(url);
      image.EndInit();
      return (ImageSource) image;
    }

    internal static async Task<string> ImageToBase64(string image)
    {
      string base64;
      using (HttpClient client = new HttpClient())
        base64 = "data:image/webp;base64," + Convert.ToBase64String(await client.GetByteArrayAsync(image));
      return base64;
    }

    internal static ImageSource Base64ToImage(string base64)
    {
      BitmapImage image = new BitmapImage();
      image.BeginInit();
      image.StreamSource = (Stream) new MemoryStream(Convert.FromBase64String(base64));
      image.EndInit();
      return (ImageSource) image;
    }
  }
}
