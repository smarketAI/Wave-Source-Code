﻿// Decompiled with JetBrains decompiler
// Type: WaveWindows.Interfaces.Script
// Assembly: WaveWindows, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 488E03D7-BB68-44F9-AFCF-41C1F1EA00C6
// Assembly location: C:\Users\chase\AppData\Local\Wave\WaveWindows.exe

using Newtonsoft.Json;

#nullable disable
namespace WaveWindows.Interfaces
{
  internal class Script
  {
    [JsonProperty("title")]
    internal string Title { get; set; }

    [JsonProperty("game")]
    internal ScriptGame Game { get; set; }

    [JsonProperty("verified")]
    internal bool Verified { get; set; }

    [JsonProperty("key")]
    internal bool HasKey { get; set; }

    [JsonProperty("isPatched")]
    internal bool Patched { get; set; }

    [JsonProperty("script")]
    internal string Source { get; set; }

    [JsonProperty("slug")]
    internal string Slug { get; set; }
  }
}
